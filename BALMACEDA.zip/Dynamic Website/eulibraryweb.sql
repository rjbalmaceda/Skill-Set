-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2018 at 03:40 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eulibraryweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookrevs`
--

CREATE TABLE `bookrevs` (
  `br_id` int(10) NOT NULL,
  `br_title` varchar(500) NOT NULL,
  `br_author` varchar(256) NOT NULL,
  `br_year` int(4) NOT NULL,
  `br_reviewer` varchar(256) NOT NULL,
  `br_file` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookrevs`
--

INSERT INTO `bookrevs` (`br_id`, `br_title`, `br_author`, `br_year`, `br_reviewer`, `br_file`) VALUES
(1, 'Alquieleta BOOK REVIEW', 'Anonymous', 2016, 'Alquieleta', 'files/uploads/bookreviews/5b072d1e731642.87683585.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `ebooks`
--

CREATE TABLE `ebooks` (
  `b_id` int(10) NOT NULL,
  `b_title` varchar(500) NOT NULL,
  `b_author` varchar(256) NOT NULL,
  `b_year` int(4) NOT NULL,
  `b_file` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ebooks`
--

INSERT INTO `ebooks` (`b_id`, `b_title`, `b_author`, `b_year`, `b_file`) VALUES
(1, 'Energy and Its Biological Resources', 'Madam Curie', 2000, 'files/uploads/ebooks/5b0723fe0f8701.78160707.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `ejournals`
--

CREATE TABLE `ejournals` (
  `j_id` int(10) NOT NULL,
  `j_title` varchar(256) NOT NULL,
  `j_volume` varchar(100) NOT NULL,
  `j_year` int(4) NOT NULL,
  `j_publisher` varchar(256) NOT NULL,
  `j_file` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ejournals`
--

INSERT INTO `ejournals` (`j_id`, `j_title`, `j_volume`, `j_year`, `j_publisher`, `j_file`) VALUES
(11, 'A subsonic lifting surface theory for wing in ground effect', '12', 2004, 'Thomas & Friends', 'files/uploads/ejournals/5b06bf1648afc9.21470592.pdf'),
(14, 'Benchmark solution for free vibration of functionally graded moderately thick annular sector plates', '12', 2003, 'Nielson Publishers Inc', 'files/uploads/ejournals/5b070c03ac87a0.58295227.pdf'),
(16, 'Dynamic analysis of functionally graded material cylinders under an impact load by a mesh free method', '12', 2016, 'Anonymous', 'files/uploads/ejournals/5b071fbf008c15.08712227.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(9) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `passwrd` varchar(100) NOT NULL,
  `accnt_type` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `middle_name`, `last_name`, `username`, `email`, `passwrd`, `accnt_type`) VALUES
(1, 'Ryan Joseph', 'Jersey', 'Balmaceda', 'rjb', 'rjbalmaceda@up.edu.ph', '$2y$10$w6VYns9Uo8mgUOXMxTpLoeBVjZSP2dnTE7VafGGmQjWea.T/r9GvW', 1),
(2, 'John Rowland', 'Jardin', 'Adormeo', 'jrja', 'jr_adormeo@yahoo.com.ph', '$2y$10$Yy6t/TJR1hvg6AUqYthW6uzRw6uTxclFl2PkOHaQPdM7OdFTR2j8O', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookrevs`
--
ALTER TABLE `bookrevs`
  ADD PRIMARY KEY (`br_id`);

--
-- Indexes for table `ebooks`
--
ALTER TABLE `ebooks`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `ejournals`
--
ALTER TABLE `ejournals`
  ADD PRIMARY KEY (`j_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookrevs`
--
ALTER TABLE `bookrevs`
  MODIFY `br_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ebooks`
--
ALTER TABLE `ebooks`
  MODIFY `b_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ejournals`
--
ALTER TABLE `ejournals`
  MODIFY `j_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
