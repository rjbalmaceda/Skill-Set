<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../styles/style.css">
        <link href="../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
        <link rel="icon" href="../files/pictures/logo/mseuf.png">
        <title>Collection Development Policy | MSEUF University Libraries</title>
    </head>
    <body>
        <div class="user_status">
            <?php
                if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 1){
                    echo '<span><form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                            </form>
                            <form action="admin/dashboard.php">
                                <input class="signoutbutton" type="submit" value="Admin Dashboard"/>
                            </form>
                        </span>';
                }
                else if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 2){
                    echo '<form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                        </form>';
                }
                else{
                    echo "<p>Hello <b>GUEST!</b><a href='signinout/signin.php'>Sign In</a></p>";
                }
            ?>
        </div>
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img src="../files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1>UNIVERSITY LIBRARIES</h1>
                        <img src="../files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a id="active" href="../about.php">About</a></li> 
                        <li><a href="../personnel.php">Personnel</a></li>
                        <li><a href="../facilities.php">Facilities</a></li>
                        <li><a href="../services.php">Services</a></li>
                        <li class="search-bar">
                            <form method="post" action="../misc/search.php">
                                <input type="text" name="search" placeholder="Search for files here..." />
                                <button class="search-button" type="submit" name="submit-search">Search</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="main">
                <div class="direct">
                    <ul class="breadcrumb">
                        <li class="back-button"><a href="../about.php"><i class="fa fa-arrow-left"></i></a></li>
                        <li><a href="../about.php">About</a></li>
                        <li>Collection Development Policy</li>
                    </ul>
                </div>
                <div class="card-title">
                    <p>Collection Development Policy</p>
                </div>
                <div class="card-with-title">
                    <div class="card-content" style="font-size: 24px">
                        <p>The University Libraries of the Manuel S. Enverga University Foundation drafted a Collection Development Policy in order to better govern the flows and processes the University, patrons and locals must do and act upon. As well as to help in the maintenance, preservation, conservation and protection of its collection.</p>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript" src="../scripts/script.js"></script>
    </body>
</html>