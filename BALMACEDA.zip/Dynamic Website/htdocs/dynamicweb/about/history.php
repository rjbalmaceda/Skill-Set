<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../styles/style.css">
        <link href="../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
        <link rel="icon" href="../files/pictures/logo/mseuf.png">
        <title>History | MSEUF University Libraries</title>
    </head>
    <body>
        <div class="user_status">
            <?php
                if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 1){
                    echo '<span><form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                            </form>
                            <form action="admin/dashboard.php">
                                <input class="signoutbutton" type="submit" value="Admin Dashboard"/>
                            </form>
                        </span>';
                }
                else if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 2){
                    echo '<form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                        </form>';
                }
                else{
                    echo "<p>Hello <b>GUEST!</b><a href='signinout/signin.php'>Sign In</a></p>";
                }
            ?>
        </div>
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img src="../files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1>UNIVERSITY LIBRARIES</h1>
                        <img src="../files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a id="active" href="../about.php">About</a></li> 
                        <li><a href="../personnel.php">Personnel</a></li>
                        <li><a href="../facilities.php">Facilities</a></li>
                        <li><a href="../services.php">Services</a></li>
                        <li class="search-bar">
                            <form method="post" action="../misc/search.php">
                                <input type="text" name="search" placeholder="Search for files here..." />
                                <button class="search-button" type="submit" name="submit-search">Search</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="main">
                <div class="direct">
                    <ul class="breadcrumb">
                        <li class="back-button"><a href="../about.php"><i class="fa fa-arrow-left"></i></a></li>
                        <li><a href="../about.php">About</a></li>
                        <li>History</li>
                    </ul>
                </div>
                <div class="card-title">
                    <p>History</p>
                </div>
                <div class="card-with-title">
                        When the Luzonian Colleges admitted its first batch of enrollees in the summer of 1947, its library was in one small room which used to be a garage in the old Lopez building located at the poblacion. It had about 1,200 volumes of books, most of which were borrowed. Some of them were donated or loaned by the founder and the faculty themselves, among whom were the families of Don Froilan Lopez, Drs. Manuel Enverga, Tobias Enverga, Cesar Villariba, Jose Eleazar, Atty. and Mrs. Teotimo Atienza, Judge Hugo Arellano, Mariano Ilano, Manuel De Vera, Vicente Verora, Crisanto Tadiosa, Paterno Africa, Alipio Sanga, Paciencia Daleon, Pura Buenaventura, Iluminada Torres, Asuncion Flores, and others.

                        Carmen A. Forcadela organized the library with one library assistant. It was a one-woman show as Miss Forcadela catalogued the holdings of the budding library and did other odd jobs to make the garage look like a real library.
                        
                        When the first owned building of the school was erected in 1950 in the corner of Granja and Cabana Streets, both the college and the high school libraries were relocated in the fourth floor of the new building. The library was allotted a bigger space than it used to occupy in the Lopez building. It had a 100-seating capacity and more library assistants. Ireneo Juntereal, Exequiel Larita, Rosalinda Tambiloc and Marciana Calubayan assisted the Chief Librarian.
                        
                        Library holdings grew substantially in 1958. The book collection reached 4,629 volumes. This required Miss Forcadela to recommend the creation of a new position for assistant librarian and the hiring of two additional librarians. Rosalinda Tambiloc was promoted to assistant librarian while Nora Ratuiste and Lydia Manalo were appointed librarians.
                        
                        An additional library for grade school pupils was housed in another building in the corner of Granja and Burgos Streets sometime in the ‘60s. Eventually, the Technology Department required another library due to the upsurge in its student population in 1963. With the appointment of new librarians, Ophelia Reynoso and Corazon Pereyra, Miss Forcadela assumed the position of Chief Librarian on August 1, 1965.
                        
                        In 1969, the main library became the High School and Law Library. Later on, the University Council decided to relocate the Law Library to the second floor of the new Arts and Sciences Education building at the University Site in Ibabang Dupay. An innovation in the new library system was the organization of the audio-visual center, adjacent to the main library, which at that time had a movie projector for 8mm audio visual materials and a music room with recording and playback devices. 
                        
                        Another library for commerce, technology and architecture building was established.  As the students and faculty members in the new Commerce-Technology Building radically increased in enrollment, the entire library collection also rose to 22,071 volumes. Purchase of books, professional journals and other instructional materials became a priority as the institution grew.
                        
                        In 1970, shortly after the University became a foundation. Miss Forcadela left for the United States. The reorganization in July 1971 saw Nora R. Bardelosa as the new Chief Librarian.
                        
                        The MSEUF Library in the main campus had seven branches. The main library was renamed Dr. Tobias Y. Enverga Memorial Library on August 29, 1985 in honor of the late Executive Vice President who contributed to the growth and development of the institution. A special ceremony to highlight the legacy of the late Dr. Toby, as he was fondly called in the University, was held.
                        
                        Guest of honor was his wife, Marcela, his daughter Dulcinea  Enverga-Abcede and son-in-law Dr. Romulo Magsino, an outstanding educator in Canada. During the unveiling ceremony of the marker, her daughter announced her family’s donation of 500 books from the collection of her late father.
                        
                        The other branches of the library system were located in the Architecture building, Physical Education, High School and Elementary departments. The MSEUF library units received book donations from Asia Foundation, Thomas Jefferson Cultural Center, Books Across the Seas Program, the Rotary Club University District, ISIS International and the alumni.
                        
                        As Chief Librarian, Mrs. Bardelosa transformed the library into a learning hub until she retired in 2001. Along with the construction of the new library complex in 2001 for the centralization of the libraries of the University was the appointment of a new library director, Mrs. Teresita DJ. Magbag. She proposed development plans for the library services and its facilities with the construction of a new library complex. 
                        
                        In late 2001, after the new library complex was built and furnished, the branch libraries of the University, with the exception of the College of Law and the Grade School Libraries, were transferred and centralized at the new library. The collections were put together and organized into sections namely, the Circulation and Reserve Section where all books of the different colleges were housed; the Reference and Filipiniana Section for the general references and Filipiniana materials, and the Periodicals Section for the serials and other continuing resources. There was also the Technical Services Unit where all newly acquired books were processed; the Collection Maintenance Unit including the bindery area to repair damaged books and store non-circulating books. A library science classroom was designed for the use of all students taking up library science and a library staff room that doubled as a lounging area for all staff was set up. A spacious reading area was also provided for students and other users.
                        
                        In June 2002, the Library conducted the first in-service training on “Focusing on Client-Centered Reader’s Services in the MSEUF Libraries”. It aimed to train all the library staff and the student assistants to render quality service to all library clients.
                        
                        The new University Libraries were blessed in 2003. Along with the blessing of the new Library Complex was the inauguration of the Museum and the MSEUF Memorabilia. The library purchased the Follett, a software to automate the services of the library, such as borrowing and returning books, computerization of student’s records, and automation of the technical processing of books. The OPAC from Follett was operational at the main entrance of the 2nd floor of the reading area. Library internet via PLDT was also started. 
                        
                        In 2004, the library started its Current Awareness Program by sending the photocopies of the table of contents of the new journals to every academic department. Books were also barcoded for security purposes and for easy inventory.
                        
                        The following year, 2005, the library started to encode the records of students, faculty, staff and non-teaching personnel in the Follett software. Their pictures were also taken so that borrowing and returning will no longer be tedious. In the same year, barcoding for students, faculty, staff and non-teaching personnel’s IDs was provided. For fast access to information, the library put up an Internet Section with 10 units of computers and named the Library User Information Systems Section (LUISS). 
                        
                        The use of the OPAC, that replaced the card catalog, proved to be useful to library clients. For aesthetic appeal, the OPAC workstations were placed at the entrance of the reading area with functionally designed stands. There were also OPAC workstations in every section of the library. The library conference room continuously became the venue of university wide activities. The library became the showcase of the University, welcoming students, teachers and administrators of other schools coming to the University.
                        The Library organized a library committee in every academic unit to rationalize book selection. With every academic unit represented, the Library set up a University wide Library Committee that ensured relevance and equity in book selection and purchases of other resources.
                        
                        In 2006, the library strengthened foundation grants, gifts and exchange programs. The Educational Media Resource Center (EMRC) Office was moved from AEC Building to the 2nd Floor of the Library Complex besides the Library Seminar Hall. In 2007, Mrs. Magbag retired and she was replaced by Assistant Director Dr. Augusta Rosario A. Villamater who recruited and hired licensed librarians. Mrs. Rosario C. Rago take charge of the EMRC as Coordinator from _______ to _______2008. Mrs. Rago edited the Guidelines in the use of EMRC Function Rooms and the AEC Little Theater.
                        
                        Dr. Villamater made use of emerging technologies in the services of the library. The Library started its electronic journals subscription in December 2007 with 100 titles equally divided among the different colleges. The University Libraries was also the first to subscribe to the digital format of Manila Times among schools in Lucena City. As President of Quezon Librarians Association (now LAQueP-LInc), Dr. Villamater initiated a library tour for benchmarking, exposure and enhancement of library services.
                        
                        In 2008, the library staff attended national, regional, and provincial trainings, seminars, conferences for professional development even as active membership in professional organization was encouraged. The University Libraries hired two (2) registered librarians namely Myrna P. Macapia and Charlyn P. Salcedo. There was continuous renewal of subscriptions to both print and non-print journals. The Library also subscribed to the Philippine Daily Inquirer in DVD format. Mr. Liberato A. Albacea took over as coordinator (now supervisor) of EMRC.
                        
                        The Basic Education Department Library introduced an improved library orientation or instruction program using technology. The BED Library launched its Reading Program entitled “The Stars of Knowledge” to build students’ passion for reading and love for books. Library automation utilized the Infolib Library System in the Secondary School Library. The staff did continuous indexing and abstracting for wide access and easy retrieval of articles. Moreover, the staff developed a library website for easy dissemination of information.
                        
                        In 2009, the new Basic Education Department Library was built to house the Grade School and Secondary School Library. EMRC IV was also transferred to the new Basic Education Department Building to accommodate BED activities. For fast retrieval and access to the collection of the library, workstations for OPAC of Follett System were replaced by flat screens and highly equipped computers to avoid delay in information retrieval. The Law Library at the Don Froilan Lopez Building utilized the Infolib as the library automation system. Internet connection was provided that allowed law students to do electronic research. The University also started offering the Bachelor of Library and Information Science (BLIS) program with eight students. The EMRC office was moved at the Ground Floor (formerly High School faculty room and principal’s office) of the Library Complex. The renovation of the AEC Little Theater started and air-conditioning units were installed.
                        
                        In 2010, the library strengthened its linkages with national, regional, and local library organizations. Dr. Villamater was elected treasurer of PLAI (Philippine Librarians Association, Inc.)-Southern Tagalog Region Librarian Council, president of the Librarians Association of Quezon Province-Lucena, Inc. (LAQueP-LInc), and was a member of several professional organizations. The library hired two registered librarians, Geraldine Mallo and Sheryl C. Farquerabao and additional technical staff for EMRC, Geobert delos Reyes.
                        
                        In 2011, the library subscribed to Expanded Academic ASAP from Gale Company with more than 3,000 full-text journal titles. Subscribed journals were indexed to facilitate retrieval of information utilizing more open access databases of electronic journals such as Directory of Open Access Journals (DOAJ), Educational Resources Information Center (ERIC), Philippine E-Journals, Philippine Journals Online, Filipiniana.net. These links are provided in the Enverga Library Website (www.envergalibrary.wordpres.com) for accessibility and ease of retrieval. 
                        
                        Also, the Basic Education Department Library started its library automation through the Infolib. The BED Library also featured Kids Infobits, an add-on of the Expanded Academic ASAP to facilitate online researches of the grade school and high school students. The Law Library also subscribed to additional online journals thru Expanded Academic ASAP. The restructured Infolib System for the Law Library automation was completed that facilitated its circulation and cataloging procedures.
                        
                        An IE Log System (computerized log system) was installed near the entrance of the University Libraries to log library users who come to the library. In addition, the library purchased the MARC Magician software to arrange and produce the catalog cards for new acquisitions encoded with the use of the Follett software. 
                        
                        There was continuous purchase of books and non-books materials for the basic education, tertiary and graduate levels. The library beefed up its collection of reference and Filipiniana materials and subscriptions of print journals, electronic journals, newspapers and newspapers in DVD format to enhance accessibility of information. The University Libraries used some open access journals and other e-books to broaden the information retrieval through links in the library website. Continuously updating its own website for accessibility of information about the library and its services, the University Libraries also built accounts in social networking sites to reach its clients.
                        
                        To protect its collection, the Library installed a CCTV video camera security system even as it enjoys WiFi accessibility for a wider range of research possibilities.
                        
                        
                        In 2012, the library hired an additional librarian Aisa C. Garcia, and a technical staff, Ronwell C. Ilagan for the Educational Media Resource Center. 
                        
                        The library also provided links for other open access electronic resources such as e-books (Project Gutenberg) and abstracts and indexes of theses and dissertations namely Dissertation.com and the Open Thesis. Additional Log-in System in the Circulation and Reserve Section was installed with additional cables in other sections of the library.
                        
                        To ensure appropriate and equitable book selection, the University Libraries linked up with publishers to undertake book selection in major publishing houses in Singapore. Deans, associate deans and department chairs have been doing book selection in Singapore since 2010 for book selection.
                        
                        In October 2012, the University Libraries subscribed to Britannica Online, a database consisting of hundreds of thousands of articles, biographies, videos, images, and web sites ‘links. There are also 500 virtual cards for remote access of the database given to permanent faculty members of the University and affiliate campuses.
                        
                        In the same year, more innovations were added to the library: an additional log-in system in each section of the library; e-theses in the Reference and Filipiniana Section and the Institute of Graduate Studies & Research Library to meet the demands of intensive research.
                        
                        The Information Technology Department (ITD) started managing the subscribed electronic journals (Expanded Academic ASAP) to ensure security and address technical issues such as providing remote access control to Expanded Academic ASAP in the affiliate campuses. 
                            
                        Subscribed journals were indexed to facilitate retrieval of information and additional open access websites were made available to users such as the Directory of Open Access Journals (DOAJ), Educational Resources Information Center (ERIC), Free Medical Journals, HighWire Press, ibiblio, Online Journals. Org., Open Science Directory, Philippine E-Journals, Scitation, Turnit, UP Diliman Journals, BioMed Central, and Plos One. These links are in the Enverga Library Website (www.envergalibrary.wordpres.com) for accessibility and retrieval.
                        
                        The Library also provided links for other open access electronic resources such as e-books like Project Gutenberg, Bookboon.com, Cogprints, Getfreeebooks, Globuz Publishing, Intech, and Planet ebook. Similarly, the Library also provided links for the open access theses and dissertations like Dissertation.com, Open Thesis, and PQDT Open.
                        
                        Automated log-in systems were provided in the different sections of the library and in the front desk by the entrance of the library to generate statistics on library usage. Electronic theses were also provided to facilitate researches.
                        
                        In late 2012, the library hired Ryan Joseph Balmaceda as technical staff for the Educational Media Resource Center. In 2013, a new batch of library staff, librarians, Zoren Alcantara and May Anyayahan, and IT, John Erben Renigado were hired for the Library and the EMRC.
                        
                        In 2013, the University Libraries regularly conduct an Information Literacy Program for freshmen students and new faculty members. ILP for students is in three (3) series: Series 1 includes Library Orientation through audio visual presentation (AVP) that discusses library facilities, services, and resources; Library Instruction Program on the use of electronic resources such as the Expanded Academic ASAP, Britannica Online (Academic Edition), RL Newspapers in DVD Form, and other free access e-books, e-journals, and e-theses; and the library tour in all library facilities; 
                        
                        Series 2 covers Library Instruction on the use of Online Public Access Catalog (OPAC) and My Info, Dewey Decimal Classification Scheme, and the Card Catalog; and Series 3 includes Library Instruction on the use of General Reference Materials such as encyclopedias, dictionaries, almanacs, atlases, etc. and the serials such as journals and magazines. Series 3 also includes hands-on use of OPAC, my Info, and electronic resources.
                        
                        The University Libraries hired another two (2) librarians namely Zoren B. Alcantara and May C. Anyayahan who are both a graduate of Bachelor of Library and Information Science. Along with this was the retirement of the two (2) library staff namely Mrs. Eufemia D. Dalugdog formerly assigned at the Basic Education Department Library and Mrs. Rebecca A. Mendoza from Law Library. A smaller EMRC III was created to accommodate major and smaller classes, EMRC V at the Nursing Building as well as the EMRC VI (A,B,C) were created to service more students and the sound system of the AEC Little Theater was replaced.
                        
                        Today, the University Library provides services not only to its faculty, students, and alumni but also to researchers of other libraries and institutions. Its professional staff has grown to cope with the needs of an increasing number of clientele. The MSEUF library system continues to provide research services and other academic undertakings in the University and in the community of scholars. The MSEUF Libraries continuously strives to be one of the biggest and most updated libraries in the Calabarzon region.
                        
                </div>
            </div>
        </div>
        <script type="text/javascript" src="../scripts/script.js"></script>
    </body>
</html>