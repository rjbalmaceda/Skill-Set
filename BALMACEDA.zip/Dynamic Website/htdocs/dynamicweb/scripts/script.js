// Navigation Bar fix at the top when scrolled

window.onscroll	= function() {fixNavBar()};

var menu = document.getElementById("navbar");
var menubg = document.getElementById("menu");
var sticky = menu.offsetTop;
var stickybg = menubg.offsetTop;

function fixNavBar(){
	if (window.pageYOffset >= stickybg) {
	    menu.classList.add("sticky");
	  } else {
	    menu.classList.remove("sticky");
	  }
}

// Real time and date

function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);

    var greeting = "";
    if(h >= 0 && h < 12){
    	greeting = "Good Morning!";
    }
    else if(h >= 12 && h < 18){
    	greeting = "Good Afternoon!";
    }
    else if(h >= 18 && h <= 23){
    	greeting = "Good Evening!";
    }

    document.getElementById('greet').innerHTML = greeting;

    var suffix = "AM";
	if (h >= 12) {
    suffix = "PM";
    h = h - 12;
	}
	if (h == 0) {
	 h = 12;
	}

    document.getElementById('time').innerHTML = h + ":" + m + ":" + s + " " + suffix;

	var currentDate = new Date(),
      day = currentDate.getDate(),
      month = currentDate.getMonth() + 1,
      year = currentDate.getFullYear();

    document.getElementById('date').innerHTML = month + "/" + day + "/" + year;
    var t = setTimeout(startTime, 500);
}

function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}