<?php
	if(isset($_POST['submit'])){
		session_start();
		session_unset();
		session_destroy();
		header('Location: ../index.php?msg=' . urlencode(base64_encode("You are now logged out!")));
		exit();
	}
?>