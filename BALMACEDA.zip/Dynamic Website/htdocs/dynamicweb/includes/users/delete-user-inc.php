<?php
	
	include "../dbh-inc.php";

		if (isset($_GET['del'])) {
		$id = $_GET['del'];
		
		mysqli_query($conn, "DELETE FROM users WHERE user_id=$id");
		$_SESSION['message'] = "Address deleted!"; 
		header('location: ../../admin/users/userlist.php?delete=success');
	}

?>