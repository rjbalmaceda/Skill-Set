<?php
	if(isset($_POST['submit'])){
		include_once '../dbh-inc.php';

		$id = mysqli_real_escape_string($conn, $_POST['id']);
		$fname = mysqli_real_escape_string($conn, $_POST['fname']);
		$mname = mysqli_real_escape_string($conn, $_POST['mname']);
		$lname = mysqli_real_escape_string($conn, $_POST['lname']);
		$username = mysqli_real_escape_string($conn, $_POST['username']);
		$email = mysqli_real_escape_string($conn, $_POST['email']);
		$password = mysqli_real_escape_string($conn, $_POST['password']);
		$confirmpassword = mysqli_real_escape_string($conn, $_POST['confirmpassword']);
		$accnt_type = mysqli_real_escape_string($conn, $_POST['accnt_type']);

		if(empty($fname) || empty($lname) || empty($username) || empty($email) || empty($password) || empty($confirmpassword)){
			header("Location: ../../admin/users/edituser.php?update=empty");
			exit();
		}
		else{
			//Check if first and last are valid
			if(!preg_match("/^[a-zA-Z\s]*$/", $fname) || !preg_match("/^[a-zA-Z\s]*$/", $mname) || !preg_match("/^[a-zA-Z\s]*$/", $lname)){
				header("Location: ../../admin/users/edituser.php?update=invalid");
				exit();
			}
			else{
				//Check if email is valid
				if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
					header("Location: ../../admin/users/edituser.php?update=invalid_email");
					exit();
				}
				else{
					$sql = "SELECT * FROM users WHERE user_id='$username'";
					$result = mysqli_query($conn, $sql);
					$resultCheck = mysqli_num_rows($result);

					if($resultCheck > 0){
						header("Location: ../../admin/users/edituser.php?update=usernametaken");
						exit();
					}
					else{
						//Password rechecking
						if(!($password == $confirmpassword)){
							header("Location: ../../admin/users/edituser.php?update=passwordnotmatch");
							exit();
						}
						else{
							//Password hashing
							$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
							//Inserting the new user into the database
							$sql = "UPDATE users SET first_name='$fname', middle_name='$mname', last_name='$lname', username='$username', email='$email', passwrd='$hashedPassword', accnt_type='$accnt_type' WHERE user_id='$id';";
							mysqli_query($conn, $sql);
							header("Location: ../../admin/users/userlist.php?update=success?");
							exit();
						}
					}
				}
			}
		}
	}
	else{
		header("Location: ../signinout/signup.php");
		exit();
	}

?>