<?php
	include "../dbh-inc.php";

	if (isset($_GET['del'])) {
		$id = $_GET['del'];

		$query = mysqli_query($conn, "SELECT j_file FROM ejournals WHERE j_id=$id");
		$row = mysqli_fetch_array($query);
		$path = "../../".$row['j_file'];
		if(!unlink($path)){
			header('Location: ../../admin/ejournal/ejournallist.php?delete=error');
			exit();
		}else{
			mysqli_query($conn, "DELETE FROM ejournals WHERE j_id=$id");
			$_SESSION['message'] = "Address deleted!"; 
			header('Location: ../../admin/ejournal/ejournallist.php?delete=success');
			exit();
		}
	}

?>