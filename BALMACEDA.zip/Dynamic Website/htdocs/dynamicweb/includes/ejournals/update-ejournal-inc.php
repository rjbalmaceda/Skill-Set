<?php
	if(isset($_POST['submit'])){
		include '../dbh-inc.php';

		$id = mysqli_real_escape_string($conn, $_POST['j_id']);
		$title = mysqli_real_escape_string($conn, $_POST['j_title']);
		$volume = mysqli_real_escape_string($conn, $_POST['j_volume']);
		$year = mysqli_real_escape_string($conn, $_POST['j_year']);
		$publisher = mysqli_real_escape_string($conn, $_POST['j_publisher']);

		if(empty($title) || empty($volume) || empty($year) || empty($publisher)){
			header("Location: ../../admin/ejournal/editejournal.php?upload=field_empty");
			exit();
		}else{
				if(!preg_match("/^[0-9]*$/", $year)){
					header("Location: ../../admin/ejournal/editejournal.php?upload=invalid_year");
					exit();
				}else{

					$sql = "UPDATE ejournals SET j_title='$title', j_volume='$volume', j_year='$year', j_publisher='$publisher' WHERE j_id='$id';";
					mysqli_query($conn, $sql);

					header("Location: ../../admin/ejournal/ejournallist.php?update=success");
					exit();
				}
		}
	}
?>