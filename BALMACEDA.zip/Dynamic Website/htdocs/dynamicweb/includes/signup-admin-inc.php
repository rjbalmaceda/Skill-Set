<?php
	if(isset($_POST['submit'])){
		include_once 'dbh-inc.php';

		$fname = mysqli_real_escape_string($conn, $_POST['fname']);
		$mname = mysqli_real_escape_string($conn, $_POST['mname']);
		$lname = mysqli_real_escape_string($conn, $_POST['lname']);
		$username = mysqli_real_escape_string($conn, $_POST['username']);
		$email = mysqli_real_escape_string($conn, $_POST['email']);
		$password = mysqli_real_escape_string($conn, $_POST['password']);
		$confirmpassword = mysqli_real_escape_string($conn, $_POST['confirmpassword']);
		$accnt_type = mysqli_real_escape_string($conn, $_POST['accnt_type']);

		if(empty($fname) || empty($lname) || empty($username) || empty($email) || empty($password) || empty($confirmpassword)){
			header("Location: ../signinout/signup.php?signup=empty");
			exit();
		}
		else{
			//Check if first and last are valid
			if(!preg_match("/^[a-zA-Z\s]*$/", $fname) || !preg_match("/^[a-zA-Z\s]*$/", $mname) || !preg_match("/^[a-zA-Z\s]*$/", $lname)){
				header("Location: ../signinout/signup.php?signup=invalid");
				exit();
			}
			else{
				//Check if email is valid
				if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
					header("Location: ../signinout/signup.php?signup=invalid_email");
					exit();
				}
				else{
					$sql = "SELECT * FROM users WHERE user_id='$username'";
					$result = mysqli_query($conn, $sql);
					$resultCheck = mysqli_num_rows($result);

					if($resultCheck > 0){
						header("Location: ../signinout/signup.php?signup=usernametaken");
						exit();
					}
					else{
						//Password rechecking
						if(!($password == $confirmpassword)){
							header("Location: ../signinout/signup.php?signup=passwordnotmatch");
							exit();
						}
						else{
							//Password hashing
							$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
							//Inserting the new user into the database
							$sql = "INSERT INTO users (first_name, middle_name, last_name, username, email, passwrd, accnt_type) VALUES ('$fname', '$mname', '$lname', '$username', '$email', '$hashedPassword', '$accnt_type');";
							mysqli_query($conn, $sql);
							header("Location: ../admin/users/userlist.php?signup=success");
							exit();
						}
					}
				}
			}
		}
	}
	else{
		header("Location: ../signinout/signup.php");
		exit();
	}

?>