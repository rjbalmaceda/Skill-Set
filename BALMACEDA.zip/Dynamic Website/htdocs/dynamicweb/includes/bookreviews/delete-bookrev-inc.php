<?php
	include "../dbh-inc.php";

	if (isset($_GET['del'])) {
		$id = $_GET['del'];

		$query = mysqli_query($conn, "SELECT br_file FROM bookrevs WHERE br_id=$id");
		$row = mysqli_fetch_array($query);
		$path = "../../".$row['br_file'];
		if(!unlink($path)){
			header('Location: ../../admin/bokreview/bookrevlist.php?delete=error');
			exit();
		}else{
			mysqli_query($conn, "DELETE FROM bookrevs WHERE br_id=$id");
			$_SESSION['message'] = "Address deleted!"; 
			header('Location: ../../admin/bookreview/bookrevlist.php?delete=success');
			exit();
		}
	}

?>