<?php
	if(isset($_POST['submit'])){
		include '../dbh-inc.php';

		$id = mysqli_real_escape_string($conn, $_POST['id']);
		$title = mysqli_real_escape_string($conn, $_POST['title']);
		$author = mysqli_real_escape_string($conn, $_POST['author']);
		$year = mysqli_real_escape_string($conn, $_POST['year']);
		$reviewer = mysqli_real_escape_string($conn, $_POST['reviewer']);

		if(empty($title) || empty($author) || empty($year) || empty($reviewer)){
			header("Location: ../../admin/bookreview/editbookrev.php?upload=field_empty");
			exit();
		}else{
				if(!preg_match("/^[0-9]*$/", $year)){
					header("Location: ../../admin/bookreview/editbookrev.php?upload=invalid_year");
					exit();
				}else{

					$sql = "UPDATE bookrevs SET br_title='$title', br_author='$author', br_year='$year', br_reviewer='$reviewer' WHERE br_id='$id';";
					mysqli_query($conn, $sql);

					header("Location: ../../admin/bookreview/bookrevlist.php?update=success");
					exit();
				}
		}
	}
?>