<?php
	if(isset($_POST['submit'])){
		include '../dbh-inc.php';

		$title = mysqli_real_escape_string($conn, $_POST['title']);
		$author = mysqli_real_escape_string($conn, $_POST['author']);
		$year = mysqli_real_escape_string($conn, $_POST['year']);

		$file = $_FILES['file'];

		$fileName = $_FILES['file']['name'];
		$fileTmpName = $_FILES['file']['tmp_name'];
		$fileSize = $_FILES['file']['size'];
		$fileError = $_FILES['file']['error'];
		$fileType = $_FILES['file']['type'];

		$fileExt = explode('.', $fileName);
		$fileActualExt = strtolower(end($fileExt));

		$allowed = array('pdf', 'doc', 'docx');

		if(in_array($fileActualExt, $allowed)){
			if($fileError === 0){
				if($fileSize < 100000000){

					if(empty($title) || empty($author) || empty($year)){
						header("Location: ../../admin/ebook/ebooklist.php?upload=field_empty");
						exit();
					}else{
							if(!preg_match("/^[0-9]*$/", $year)){
								header("Location: ../../admin/ebook/ebooklist.php?upload=invalid_year");
								exit();
							}else{
								
								$fileNameNew = uniqid('', true).".".$fileActualExt;
								$fileDestination = 'files/uploads/ebooks/'.$fileNameNew;
								move_uploaded_file($fileTmpName, '../../'.$fileDestination);

								$sql = "INSERT INTO ebooks (b_title, b_author, b_year, b_file) VALUES ('$title', '$author', '$year', '$fileDestination');";
								mysqli_query($conn, $sql);
								
								header("Location: ../../admin/ebook/ebooklist.php?upload=success");
								exit();
							}
					}
				}else{
					header("Location: ../../admin/ebook/ebooklist.php?fileSizeTooBig");
					exit();
				}
			}else{
				header("Location: ../../admin/ebook/ebooklist.php?fileError");
				exit();
			}
		}
		else{
			header("Location: ../../admin/ebook/ebooklist.php?fileExtNotAllowed");
			exit();
		}
	}
?>