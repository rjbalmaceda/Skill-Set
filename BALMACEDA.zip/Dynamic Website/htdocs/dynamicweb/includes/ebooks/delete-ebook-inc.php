<?php
	include "../dbh-inc.php";

	if (isset($_GET['del'])) {
		$id = $_GET['del'];

		$query = mysqli_query($conn, "SELECT b_file FROM ebooks WHERE b_id=$id");
		$row = mysqli_fetch_array($query);
		$path = "../../".$row['b_file'];
		if(!unlink($path)){
			header('Location: ../../admin/ebook/ebooklist.php?delete=error');
			exit();
		}else{
			mysqli_query($conn, "DELETE FROM ebooks WHERE b_id=$id");
			$_SESSION['message'] = "Address deleted!"; 
			header('Location: ../../admin/ebook/ebooklist.php?delete=success');
			exit();
		}
	}

?>