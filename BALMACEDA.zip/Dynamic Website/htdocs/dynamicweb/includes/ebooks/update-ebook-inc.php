<?php
	if(isset($_POST['submit'])){
		include '../dbh-inc.php';

		$id = mysqli_real_escape_string($conn, $_POST['id']);
		$title = mysqli_real_escape_string($conn, $_POST['title']);
		$author = mysqli_real_escape_string($conn, $_POST['author']);
		$year = mysqli_real_escape_string($conn, $_POST['year']);

		if(empty($title) || empty($author) || empty($year)){
			header("Location: ../../admin/ebook/editebook.php?upload=field_empty");
			exit();
		}else{
				if(!preg_match("/^[0-9]*$/", $year)){
					header("Location: ../../admin/ebook/editebook.php?upload=invalid_year");
					exit();
				}else{

					$sql = "UPDATE ebooks SET b_title='$title', b_author='$author', b_year='$year' WHERE b_id='$id';";
					mysqli_query($conn, $sql);

					header("Location: ../../admin/ebook/ebooklist.php?update=success");
					exit();
				}
		}
	}
?>