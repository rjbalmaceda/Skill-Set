<?php

	session_start();

	if(isset($_POST['submit'])){
		include 'dbh-inc.php';

		$username = mysqli_real_escape_string($conn, $_POST['username']);
		$password = mysqli_real_escape_string($conn, $_POST['password']);

		//Error handling
		if(empty($username) || empty($password)){
			header("Location: ../signinout/signin.php?signin=empty");
			exit();
		}
		else{
			$sql = "SELECT * FROM users WHERE username='$username'";
			$result = mysqli_query($conn, $sql);
			$resultCheck = mysqli_num_rows($result);

			if($resultCheck < 1){
				header("Location: ../signinout/signin.php?signin=error");
				exit();
			}
			else{
				if($row = mysqli_fetch_assoc($result)){
					//De-hashing Password
					$hashedPwdCheck = password_verify($password, $row['passwrd']);
					if($hashedPwdCheck == false){
						header("Location: ../signinout/signin.php?signin=errorpassword");
						exit();
					}
					elseif ($hashedPwdCheck == true){
						//Signing in
						$_SESSION['u_id'] = $row['user_id'];
						$_SESSION['u_fname'] = $row['first_name'];
						$_SESSION['u_mname'] = $row['middle_name'];
						$_SESSION['u_lname'] = $row['last_name'];
						$_SESSION['u_username'] = $row['username'];
						$_SESSION['u_email'] = $row['email'];
						$_SESSION['u_accnt_type'] = $row['accnt_type'];
						// header("Location: ../index.php?signin=success");
						// header('Location: ../index.php?msg=' . urlencode(base64_encode("You have successfully logged in!")));
						echo '<meta http-equiv="Refresh" content="0;url=../index.php?msg=' . urlencode(base64_encode('You have successfully logged in!')) . '">';
						exit();
					}
				}
			}
		}
	}
	else{
		header("Location: ../signinout/signin.php?signin=error");
		exit();
	}
	
?>