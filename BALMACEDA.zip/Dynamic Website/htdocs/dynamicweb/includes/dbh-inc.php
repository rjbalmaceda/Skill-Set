<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "eulibraryweb";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

?>