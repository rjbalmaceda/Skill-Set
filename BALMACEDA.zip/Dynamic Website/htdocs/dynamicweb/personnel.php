<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="styles/style.css">
        <link rel="icon" href="files/pictures/logo/mseuf.png">
        <title>Personnel | MSEUF University Libraries</title>
    </head>
    <body>
        <div class="user_status">
            <?php
                if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 1){
                    echo '<span><form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                            </form>
                            <form action="admin/dashboard.php">
                                <input class="signoutbutton" type="submit" value="Admin Dashboard"/>
                            </form>
                        </span>';
                }
                else if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 2){
                    echo '<form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                        </form>';
                }
                else{
                    echo "<p>Hello <b>GUEST!</b><a href='signinout/signin.php'>Sign In</a></p>";
                }
            ?>
        </div>
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img src="files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1>UNIVERSITY LIBRARIES</h1>
                        <img src="files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a>
                        </li> 
                        <li><a id="active" href="personnel.php">Personnel</a></li>
                        <li><a href="facilities.php">Facilities</a>
                        </li>
                        <li><a href="services.php">Services</a></li>
                        <li class="search-bar">
                            <form method="post" action="misc/search.php">
                                <input type="text" name="search" placeholder="Search for files here..." />
                                <button class="search-button" type="submit" name="submit-search">Search</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="main">
                <div class="card-title">
                    <p>Library Personnel</p>
                </div>
                <div class="card-with-title">
                    <div class="row">
                        <div class="personnelpic" style="margin: 0 auto">
                            <img src="files/pictures/personnel/villamater.jpg" alt="villamater.jpg"/>
                            <h2>Augusta Rosario A. Villamater, EdD</h2>
                            <p>Director</p>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/casipit.jpg" alt="casipit.jpg">
                            <h2>Myrna M. Casipit, RL, MLIS, EdD (ongoing)</h2>
                            <p>Senior Librarian</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/salcedo.jpg" alt="salcedo.jpg">
                            <h2>Charlyn P. Salcedo, RL, MALS, EdD (ongoing)</h2>
                            <p>Senior Librarian</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/farquerabao.jpg" alt="farquerabao.jpg">
                            <h2>Sheryl C. Farquerabao, RL, MLIS</h2>
                            <p>Junior Librarian</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/zeta.jpg" alt="zeta.jpg">
                            <h2>Aisa G. Zeta, RL, MLIS</h2>
                            <p>Junior Librarian</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/eustaquio.jpg" alt="eustaquio.jpg">
                            <h2>Geraldine M. Eustaquio, RL, MLIS (ongoing)</h2>
                            <p>Junior Librarian</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/alcantara.jpg" alt="alcantara.jpg">
                            <h2>May A. Alcantara, RL, MLIS</h2>
                            <p>Junior Librarian</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/alcantara_z.jpg" alt="alcantara_z.jpg">
                            <h2>Zoren B. Alcantara, RL, MLIS</h2>
                            <p>Junior Librarian</p>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/mahiya.jpg" alt="mahiya.jpg">
                            <h2>Marisa C. Mahiya</h2>
                            <p>Library Staff</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/dela_puerta.jpg" alt="dela_puerta.jpg">
                            <h2>Buenafe Z. Dela Puerta</h2>
                            <p>Library Staff</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/engana.jpg" alt="engana.jpg">
                            <h2>Carolina B. Engaña</h2>
                            <p>Library Staff</p>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/albacea.jpg" alt="albacea.jpg">
                            <h2>Liberato A. Albacea</h2>
                            <p>EMRC Supervisor</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/ibias.jpg" alt="ibias.jpg">
                            <h2>Roger T. Ibias</h2>
                            <p>EMRC Staff</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/delos_reyes.jpg" alt="delos_reyes.jpg">
                            <h2>Geobert S. Delos Reyes</h2>
                            <p>EMRC Staff</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/balmaceda.jpg" alt="balmaceda.jpg">
                            <h2>Ryan Joseph J. Balmaceda, MLIS (ongoing)</h2>
                            <p>EMRC Staff</p>
                        </div>
                        <div class="personnelpic ifloat">
                            <img src="files/pictures/personnel/renigado.jpg" alt="renigado.jpg">
                            <h2>John Erben S. Renigado, MIT (ongoing)</h2>
                            <p>EMRC Staff</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script type="text/javascript" src="scripts/script.js"></script>
    </body>
</html>