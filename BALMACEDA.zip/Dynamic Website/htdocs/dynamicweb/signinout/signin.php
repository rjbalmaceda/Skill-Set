<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../styles/style.css">
		<link rel="stylesheet" type="text/css" href="../styles/signinstyle.css">
        <link rel="icon" href="../files/pictures/logo/mseuf.png">
        <title>Sign In | MSEUF University Libraries</title>
	</head>
	<body>
		<div class="main">
			<div class="login">
				<div class="card-with-title">
					<a href="../index.php">
						<div class="title-bar">
							<div class="content">
								<img src="../files/pictures/logo/mseuf.png" alt="mseuflogo.png" width="50px" height="50px">
								<p>Manuel S. Enverga University Foundation</p>
								<h1>UNIVERSITY LIBRARIES</h1>
							</div>
						</div>
					</a>
					<div class="entersignin">
						<div class="title-input">
							<h1>Sign In</h1>
						</div>
						<br>
						<form method="post" action="../includes/signin-inc.php">
							<label>Username</label><br>
							<input class="inputdes" type="text" name="username"/><br><br>
							<label>Password</label><br>
							<input class="inputdes" type="password" name="password"/><br><br><br>
							<p class="signupbut">Not yet a member? <a href="signup.php">Sign Up</a></p>
							<input class="submitbutton" type="submit" name="submit" value="Sign In"/>
						</form>
					</div>

				</div>
			</div>
		</div>
	</body>
</html>