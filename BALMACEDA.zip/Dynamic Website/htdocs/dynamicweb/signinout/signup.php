<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../styles/style.css">
		<link rel="stylesheet" type="text/css" href="../styles/signinstyle.css">
        <link rel="icon" href="../files/pictures/logo/mseuf.png">
        <title>Sign Up | MSEUF University Libraries</title>
	</head>
	<body>
		<div class="main">
			<div class="login signup-card">
				<div class="card-with-title">
					<a href="../index.php">
					<div class="title-bar">
							<div class="content">
								<img src="../files/pictures/logo/mseuf.png" alt="mseuflogo.png" width="50px" height="50px">
								<p>Manuel S. Enverga University Foundation</p>
								<h1>UNIVERSITY LIBRARIES</h1>
							</div>
						</div>
					</a>
					<div class="entersignup">
						<div class="title-input">
							<h1>Sign Up</h1>
						</div>
						<br>
						<form method="post" name="signup" action="../includes/signup-inc.php">
							<table cellpadding="10">
								<tr>
									<td>
										<label>First Name</label><br>
										<input class="inputdes" type="text" name="fname"/>
									</td>
									<td>
										<label>Middle Name</label><br>
										<input class="inputdes" type="text" name="mname"/>
									</td>
									<td>
										<label>Last Name</label><br>
										<input class="inputdes" type="text" name="lname"/>
									</td>
								</tr>
								<tr>
									<td>
										<label>Username</label><br>
										<input class="inputdes" type="text" name="username"/>
									</td>
									<td colspan="2">
										<label>Email Address</label><br>
										<input class="inputdes" type="email" name="email"/>
									</td>
								</tr>
								<tr>
									<td>
										<label>Password</label><br>
										<input class="inputdes" type="password" name="password"/>
									</td>
									<td>
										<label>Confirm Password</label><br>
										<input class="inputdes" type="password" name="confirmpassword"/>
									</td>
									<td id="signup-accnt_type">
										<label>Account Type</label><br>
										<select class="inputdes" name="accnt_type">
											<option disabled value="1">Administrator</option>
											<option value="2" selected="selected">Standard User</option>
										</select>
									</td>
								</tr>
								<tr>
									<td colspan="2">
										<p class="signupbut">Already a member? <a href="signin.php">Sign In</a></p>
									</td>
									<td>
										<input class="submitbutton" type="submit" name="submit" value="Sign Up"/>
									</td>
								</tr>
							</table>
						</form>
						<!-- <form method="post" name="signup">
							<label>Username</label><br>
							<input class="inputdes" type="text" name="username"/><br><br>
							<label>Password</label><br>
							<input class="inputdes" type="password" name="password"/><br><br>
							<label>Email address</label><br>
							<input class="inputdes" type="email" name="email"/><br><br><br>
							<p class="signupbut">Already a member? <a href="signin.php">Sign In</a></p>
							<input class="submitbutton" type="submit" value="Sign Up"/>
						</form> -->
					</div>

				</div>
			</div>
		</div>
	</body>
</html>