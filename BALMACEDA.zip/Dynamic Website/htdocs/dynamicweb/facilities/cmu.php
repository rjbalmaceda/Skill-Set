<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../styles/style.css">
        <link href="../Files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
        <link rel="icon" href="../Files/pictures/logo/mseuf.png">
        <title>Collection Maintenance Unit | MSEUF University Libraries</title>
    </head>
    <body style="margin: 0; background-color:#D3D3D3">
        <div class="user_status">
            <?php
                if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 1){
                    echo '<span><form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                            </form>
                            <form action="admin/dashboard.php">
                                <input class="signoutbutton" type="submit" value="Admin Dashboard"/>
                            </form>
                        </span>';
                }
                else if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 2){
                    echo '<form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                        </form>';
                }
                else{
                    echo "<p>Hello <b>GUEST!</b><a href='signinout/signin.php'>Sign In</a></p>";
                }
            ?>
        </div>
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img style="float: left; margin: 10px 0 0 10px" src="../Files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1 style="font-size: 50px; line-height: 80%">UNIVERSITY LIBRARIES</h1>
                        <img src="../Files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="../about.php">About</a></li> 
                        <li><a href="../personnel.php">Personnel</a></li>
                        <li><a id="active" href="../facilities.php">Facilities</a></li>
                        <li><a href="../services.php">Services</a></li>
                        <li class="search-bar" style="float:right; margin-right: 40px;">
                            <form method="post" action="../misc/search.php">
                                <input type="text" name="search" placeholder="Search for files here..." />
                                <button class="search-button" type="submit" name="submit-search">Search</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!--------------------------------------------MAIN BODY OF PAGE-------------------------------------------------------->
            <div class="main">
                <div class="direct">
                    <ul class="breadcrumb">
                        <li class="back-button"><a href="../facilities.php"><i class="fa fa-arrow-left"></i></a></li>
                        <li><a href="../facilities.php">Facilities</a></li>
                        <li>Collection Maintenance Unit</li>
                    </ul>
                </div>
                <div class="card-title">
                    <p>Collection Maintenance Unit</p>
                </div>
                 <div class="card-with-title">
                     <div class="card-img imgcover"><img src="../Files/pictures/facilities/cmu.jpg"></div>
                 </div>               
            </div>
        </div>
        <script type="text/javascript" src="../scripts/script.js"></script>
    </body>
</html>