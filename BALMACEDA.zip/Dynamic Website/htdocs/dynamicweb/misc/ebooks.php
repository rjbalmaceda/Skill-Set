<?php
    session_start();

    include '../includes/dbh-inc.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../styles/style.css">
        <link href="../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
        <link rel="icon" href="../files/pictures/logo/mseuf.png">
        <title>e-Books | MSEUF University Libraries</title>
    </head>
    <body>
        <div class="user_status">
            <?php
                if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 1){
                    echo '<span><form method="post" action="../includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                            </form>
                            <form action="../admin/dashboard.php">
                                <input class="signoutbutton" type="submit" value="Admin Dashboard"/>
                            </form>
                        </span>';
                }
                else if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 2){
                    echo '<form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                        </form>';
                }
                else{
                    echo "<p>Hello <b>GUEST!</b><a href='signinout/signin.php'>Sign In</a></p>";
                }
            ?>
        </div>
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
                
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img src="../files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1>UNIVERSITY LIBRARIES</h1>
                        <img src="../files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="../about.php">About</a></li> 
                        <li><a href="../personnel.php">Personnel</a></li>
                        <li><a href="../facilities.php">Facilities</a></li>
                        <li><a href="../services.php">Services</a></li>
                        <li class="search-bar">
                            <input placeholder="This feature is N/A"/>
                            <button class="search-button">Search</button>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!--------------------------------------------MAIN BODY OF PAGE-------------------------------------------------------->
            <div class="main">
                <div class="direct">
                    <ul class="breadcrumb">
                        <li class="back-button"><a href="../index.php"><i class="fa fa-arrow-left"></i></a></li>
                        <li><a href="../index.php">Home</a></li>
                        <li>List of e-Books</li>
                    </ul>
                </div>
                <div class="homecontainer">
                    <div class="card-title">
                        <p>List of e-Books</p>
                    </div>
                    <div class="card-with-title">
                        <?php
                            $sql = "SELECT * FROM ebooks;";
                            $result = mysqli_query($conn, $sql);
                            $resultCheck = mysqli_num_rows($result);

                            if ($resultCheck > 0) {
                                echo '<div style="overflow-x: auto"><table class="admin_users edit_table">
                                        <tr>
                                            <th>Title</th>
                                            <th>Author</th>
                                            <th>Year</th>                                        
                                            <th>View/Download</th>
                                        </tr>';                                                                                     
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo '<tr>
                                            <td>'.$row['b_title'].'</td>
                                            <td>'.$row['b_author'].'</td>
                                            <td>'.$row['b_year'].'</td>
                                            <td><a target="_blank" href="../'.$row['b_file'].'"><i class="fas fa-external-link-alt"></i></a></td>
                                        </tr>';
                                }
                                echo '</table></div>';
                            }
                            else{
                                    echo 'There are no e-Books uploaded.';
                                }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript" src="../scripts/script.js"></script>
    </body>
</html>