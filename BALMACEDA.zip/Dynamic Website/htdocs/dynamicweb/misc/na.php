<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../styles/style.css">
        <link rel="icon" href="../Files/pictures/logo/mseuf.png">
        <title>404 Error | MSEUF University Libraries</title>
    </head>
    <body style="margin: 0; background-color:#D3D3D3">
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img style="float: left; margin: 10px 0 0 10px" src="../Files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1 style="font-size: 50px; line-height: 80%">UNIVERSITY LIBRARIES</h1>
                        <img src="../Files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="../about.php">About</a></li> 
                        <li><a href="../personnel.php">Personnel</a></li>
                        <li><a href="../facilities.php">Facilities</a></li>
                        <li><a href="../services.php">Services</a></li>
                        <li class="search-bar" style="float:right; margin-right: 40px;">
                            <input placeholder="This feature is N/A" />
                            <button class="search-button">Search</button>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="main">
                This feature is not yet available                
            </div>
            <div class="footer">
                
            </div>
        </div>
        <script type="text/javascript" src="../script.js"></script>
    </body>
</html>