<?php
    session_start();

    include '../includes/dbh-inc.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../styles/style.css">
        <link href="../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
        <link rel="icon" href="../files/pictures/logo/mseuf.png">
        <title>Search Results | MSEUF University Libraries</title>
    </head>
    <body>
        <div class="user_status">
            <?php
                if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 1){
                    echo '<span><form method="post" action="../includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                            </form>
                            <form action="../admin/dashboard.php">
                                <input class="signoutbutton" type="submit" value="Admin Dashboard"/>
                            </form>
                        </span>';
                }
                else if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 2){
                    echo '<form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                        </form>';
                }
                else{
                    echo "<p>Hello <b>GUEST!</b><a href='signinout/signin.php'>Sign In</a></p>";
                }
            ?>
        </div>
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
                
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img src="../files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1>UNIVERSITY LIBRARIES</h1>
                        <img src="../files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="../about.php">About</a></li> 
                        <li><a href="../personnel.php">Personnel</a></li>
                        <li><a href="../facilities.php">Facilities</a></li>
                        <li><a href="../services.php">Services</a></li>
                        <!-- <li class="search-bar">
                            <input placeholder="This feature is N/A"/>
                            <button class="search-button">Search</button>
                        </li> -->
                    </ul>
                </div>
            </div>
            
            <!--------------------------------------------MAIN BODY OF PAGE-------------------------------------------------------->
            <div class="main">
                <!-- <div class="direct">
                    <ul class="breadcrumb">
                        <li class="back-button"><a href="../index.php"><i class="fa fa-arrow-left"></i></a></li>
                        <li><a href="../index.php">Home</a></li>
                        <li>List of e-Journals</li>
                    </ul>
                </div> -->
                <div class="homecontainer">
                    <div class="card-title">
                        <p>Search</p>
                    </div>
                    <div class="card-with-title">
                        <form method="post" action="search.php">
                            <div class="search-bar at-search-page">
                                <input type="text" name="search" placeholder="Search for files here..." />
                                <button class="search-button at-search-page-button" type="submit" name="submit-search">Search</button>
                            </div>
                        </form><hr><br>
                        <?php
                            if(isset($_POST['submit-search'])){
                                $search = mysqli_real_escape_string($conn, $_POST['search']);
                                $sql_j = "SELECT * FROM ejournals WHERE j_title LIKE '%$search%' OR j_volume LIKE '%$search%' OR j_year LIKE '%$search%' OR j_publisher LIKE '%$search%'";
                                $result_j = mysqli_query($conn, $sql_j);
                                $queryResult_j = mysqli_num_rows($result_j);

                                $sql_b = "SELECT * FROM ebooks WHERE b_title LIKE '%$search%' OR b_author LIKE '%$search%' OR b_year LIKE '%$search%'";
                                $result_b = mysqli_query($conn, $sql_b);
                                $queryResult_b = mysqli_num_rows($result_b);

                                $sql_br = "SELECT * FROM bookrevs WHERE br_title LIKE '%$search%' OR br_author LIKE '%$search%' OR br_year LIKE '%$search%' OR br_reviewer LIKE '%$search%'";
                                $result_br = mysqli_query($conn, $sql_br);
                                $queryResult_br = mysqli_num_rows($result_br);

                                if($queryResult_j > 0){
                                    echo '<div class="search-title"><p><i class="fas fa-newspaper"></i>&nbsp; <b>e-Journals</b></p></div>
                                    <div><table class="admin_users edit_table search-table">
                                            <tr>
                                                <th>Title</th>
                                                <th>Volume</th>
                                                <th>Year</th>
                                                <th>Publisher</th>                                          
                                                <th>View</th>
                                            </tr>'; 
                                    while($row  = mysqli_fetch_assoc($result_j)){
                                        echo '<tr> 
                                            <td>'.$row['j_title'].'</td>
                                            <td>'.$row['j_volume'].'</td>
                                            <td>'.$row['j_year'].'</td>
                                            <td>'.$row['j_publisher'].'</td>
                                            <td><a target="_blank" href="../'.$row['j_file'].'"><i class="fas fa-external-link-alt"></i></a></td>
                                        </tr>';
                                    }
                                    echo '</table></div><hr>';
                                }
                                if($queryResult_b > 0){
                                    echo '<div class="search-title"><p><i class="fas fa-book"></i>&nbsp; <b>e-Books</b></p></div><div><table class="admin_users edit_table search-table">
                                            <tr>
                                                <th>Title</th>
                                                <th>Author</th>
                                                <th>Year</th>
                                                <th>View</th>
                                            </tr>';
                                    while ($row = mysqli_fetch_assoc($result_b)) {
                                        echo '<tr>
                                                <td>'.$row['b_title'].'</td>
                                                <td>'.$row['b_author'].'</td>
                                                <td>'.$row['b_year'].'</td>
                                                <td><a target="_blank" href="../'.$row['b_file'].'"><i class="fas fa-external-link-alt"></i></a></td>
                                            </tr>';
                                    }
                                    echo '</table></div><hr>';
                                }
                                if($queryResult_br > 0){
                                    echo '<div class="search-title"><p><i class="fas fa-file-alt"></i>&nbsp; <b>Book Reviews</b></p></div><div><table class="admin_users edit_table search-table">
                                            <tr>
                                                <th>Title</th>
                                                <th>Author</th>
                                                <th>Year</th>
                                                <th>Reviewer</th>
                                                <th>View</th>
                                            </tr>';
                                    while ($row = mysqli_fetch_assoc($result_br)) {
                                        echo '<tr>
                                                <td>'.$row['br_title'].'</td>
                                                <td>'.$row['br_author'].'</td>
                                                <td>'.$row['br_year'].'</td>
                                                <td>'.$row['br_reviewer'].'</td>
                                                <td><a target="_blank" href="../'.$row['br_file'].'"><i class="fas fa-external-link-alt"></i></a></td>
                                            </tr>';
                                    }
                                    echo '</table></div><hr>';
                                }else{
                                    echo 'There are no results matching "<b>'.$search.'</b>"';
                                }
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript" src="../scripts/script.js"></script>
    </body>
</html>