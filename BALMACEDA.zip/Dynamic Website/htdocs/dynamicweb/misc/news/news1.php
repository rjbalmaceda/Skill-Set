<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../../styles/style.css">
        <link href="../../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
        <link rel="icon" href="../../files/pictures/logo/mseuf.png">
        <title>News & Updates | MSEUF University Libraries</title>
    </head>
    <body style="margin: 0; background-color:#D3D3D3">
        <div class="user_status">
            <?php
                if(isset($_SESSION['u_id'])){
                    echo '<form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                        </form>';
                }
                else{
                    echo "<p>Hello <b>GUEST!</b><a href='signinout/signin.php'>Sign In</a></p>";
                }
            ?>
        </div>
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img style="float: left; margin: 10px 0 0 10px" src="../../files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1 style="font-size: 50px; line-height: 80%">UNIVERSITY LIBRARIES</h1>
                        <img src="../../files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="../../index.php">Home</a></li>
                        <li><a href="../../about.php">About</a></li> 
                        <li><a href="../../personnel.php">Personnel</a></li>
                        <li><a href="../../facilities.php">Facilities</a></li>
                        <li><a href="../../services.php">Services</a></li>
                        <li class="search-bar" style="float:right; margin-right: 40px;">
                            <input placeholder="This feature is N/A" />
                            <button class="search-button">Search</button>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="main">
                <div class="direct">
                    <ul class="breadcrumb">
                        <li class="back-button"><a href="../../index.php"><i class="fa fa-arrow-left"></i></a></li>
                        <li><a href="../../index.php">Home</a></li>
                        <li>News & Updates</li>
                    </ul>
                </div>
                <div class="card-with-title">
                    <div class="title"><h1>Lib.Com hailed 2nd placer in the UCSC booth competition</h2></div>
                    <div class="card-img"><img src="../../files/pictures/newspic/lib2nd.png"></div>
                    <div class="card-content justify">
                        <p>&emsp;&emsp;Lib.Com hailed as 2nd place in the Student Organizations Booth Fair 2018. Lib.Com is one of the University accredited organization composed of Bachelor of Library and Information Science students.</p>
                        <p>&emsp;&emsp;They have received Php 4000.00 and a plaque of recognition from the University Collegiate Student Council.</p>
                        <p>&emsp;&emsp;The Booth Fair  is one of the activities for the MSEUF 71st Foundation Anniversary Celebration with the theme “Sharing the legacy of excellence” held at the MSEUF student lounge on February 13-15, 2018.</p>
                        <p>&emsp;&emsp;The Booth exhibit of the Lib.Com supports the threefold functions of the university. Instruction: The University Libraries is the big laboratory for BLIS program which houses materials needed for the program and was awarded as 2016 Most Outstanding Academic research Library. The use of electronic resources provide the instructional materials for the BLIS program. The Children Library is also a venue for storytelling sessions of Lib.Com. Research: BLIS students participate in Student Forum, Provincial and Regional Paper presentations and Community Extension Service: Librarianihan and Halamanan ng Librarian spearheaded the community extension services of the organization. The theme of the booth is the care of the environment which can be shown through the tree with vines and flowers in the presence of an animal shelf.</p>
                    </div>
                </div>             
            </div>
            <div class="footer">
                
            </div>
        </div>
        <script type="text/javascript" src="../../scripts/script.js"></script>
    </body>
</html>