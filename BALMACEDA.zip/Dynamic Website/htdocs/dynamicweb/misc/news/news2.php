<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../../styles/style.css">
        <link href="../../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
        <link rel="icon" href="../../Files/pictures/logo/mseuf.png">
        <title>News & Updates | MSEUF University Libraries</title>
    </head>
    <body style="margin: 0; background-color:#D3D3D3">
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img style="float: left; margin: 10px 0 0 10px" src="../../Files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1 style="font-size: 50px; line-height: 80%">UNIVERSITY LIBRARIES</h1>
                        <img src="../../Files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="../../index.php">Home</a></li>
                        <li><a href="../../about.php">About</a></li> 
                        <li><a href="../../personnel.php">Personnel</a></li>
                        <li><a href="../../facilities.php">Facilities</a></li>
                        <li><a href="../../services.php">Services</a></li>
                        <li class="search-bar" style="float:right; margin-right: 40px;">
                            <input placeholder="This feature is N/A" />
                            <button class="search-button">Search</button>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="main">
                <div class="direct">
                    <ul class="breadcrumb">
                        <li class="back-button"><a href="../../index.php"><i class="fa fa-arrow-left"></i></a></li>
                        <li><a href="../../index.php">Home</a></li>
                        <li>News & Updates</li>
                    </ul>
                </div>
                <div class="card-with-title">
                    <div class="title"><h1>2 University Adopted Libraries won as most functional libraries in the Division of Lucena</h1></div>
                    <div class="card-img"><img src="../../Files/pictures/newspic/adopt.png"><img src="../../Files/pictures/newspic/adopt2.png"><img src="../../Files/pictures/newspic/adopt3.png"></div>
                    <div class="card-content justify">
                        <p>&emsp;&emsp;Two of the Enverga Univeristy adopted libraries won in the recently concluded search for most functional libraries in the  Division of Lucena for Elementary and Secondary category.</p>
                        <p>&emsp;&emsp;Elvira Razon Elementary School has won as the Most Functional Library in the    elementary category while Lucena Dalahican National High School won in the secondary category.</p>
                        <p>&emsp;&emsp;Elvira Razon Aranilla has been adopted by the University Libraries this semester. Big improvement has been done in the      library like organization and rearrangement of their collections. This has been done through the cooperation of their principal Mrs. Editha Huelva and Mr.Andy Panlilio to the Enverga staff and Lib.Com.</p>
                        <p>&emsp;&emsp;While Lucena Dalahican has been adopted by the University since 2009. The University library has been constantly involved in the organization, cataloging of their collection since then. They have also donated a number of books to the said school.</p>
                        <p>&emsp;&emsp;This awards give much pride to the University Libraries to continue their Adopt-a-Library Program to serve and help nourish  the future generations of our country.</p>
                    </div>
                </div>             
            </div>
            <div class="footer">
                
            </div>
        </div>
        <script type="text/javascript" src="../../script.js"></script>
    </body>
</html>