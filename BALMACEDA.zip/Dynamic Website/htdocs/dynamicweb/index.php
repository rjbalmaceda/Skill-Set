<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./styles/style.css">
        <link href="files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
        <link rel="icon" href="files/pictures/logo/mseuf.png">
        <title>Home | MSEUF University Libraries</title>
    </head>
    <body onload="startTime()">
        <?php
            if (!empty($_GET['msg'])){
                echo '<div class="inmessage"><i class="fas fa-check"></i>&nbsp;&nbsp;&nbsp;'.base64_decode(urldecode($_GET['msg'])) . '</div>';
            }
        ?>
        <div class="user_status">
            <?php
                if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 1){
                    echo '<span><form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                            </form>
                            <form action="admin/dashboard.php">
                                <input class="signoutbutton" type="submit" value="Admin Dashboard"/>
                            </form>
                        </span>';
                }
                else if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 2){
                    echo '<form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                        </form>';
                }
                else{
                    echo "<p>Hello <b>GUEST!</b><a href='signinout/signin.php'>Sign In</a></p>";
                }
            ?>
        </div>
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
                
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img src="files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1>UNIVERSITY LIBRARIES</h1>
                        <img src="files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a id="active" href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li> 
                        <li><a href="personnel.php">Personnel</a></li>
                        <li><a href="facilities.php">Facilities</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li class="search-bar">
                            <form method="post" action="misc/search.php">
                                <input type="text" name="search" placeholder="Search for files here..." />
                                <button class="search-button" type="submit" name="submit-search">Search</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!--------------------------------------------MAIN BODY OF PAGE-------------------------------------------------------->
            <div class="main">
                <div class="homecontainer">
                        <div class="leftside">
                            <div class="buttonhome">
                                <a href="misc/ejournals.php"><div class="imagebox"><img src="files/pictures/icon/journal.png" width="80%" /><br></div>
                                <p>e-Journals</p></a>
                            </div>
                            <div class="buttonhome">
                                <a href="misc/ebooks.php"><div class="imagebox"><img src="files/pictures/icon/ebook.png" width="80%" /><br></div>
                                <p>e-Books</p> </a>   
                            </div>
                        </div>
                        <div class="feed">
                            <div class="card-title">
                                <p>News & Updates</p>
                            </div>
                            <div class="card-with-title">
                                <div class="title">
                                    <h2>Lib.Com hailed 2nd placer in the UCSC booth competition</h2>
                                </div>
                                <div class="card-img"><img src="files/pictures/newspic/lib2nd.png" alt="lib2nd.png" /></div>
                                <div class="card-content justify">
                                        <p>&emsp;&emsp;Lib.Com hailed as 2nd place in the Student Organizations Booth Fair 2018. Lib.Com is one of the
                                            University accredited organization composed of Bachelor of Library and Information Science students.
                                            &emsp;&emsp;They have received Php 4000.00 and a plaque of recognition from the University Collegiate Student Council...
                                    </p>
                                </div>
                                <div class="readmore"><a href="misc/news/news1.php">Read More</a></div>
                            </div>
                            <div class="card-with-title">
                                <div class="title">
                                    <h2>2 University Adopted Libraries won as most functional libraries in the  Division of Lucena</h2>
                                </div>
                                <div class="card-img"><img src="files/pictures/newspic/adopt.png" alt="adpot.png" /></div>
                                <div class="card-content justify">
                                        <p>&emsp;&emsp;Two of the Enverga Univeristy adopted libraries won in the recently concluded search for most functional libraries in the  Division of Lucena for Elementary and Secondary category. <br> &emsp;&emsp;Elvira Razon Elementary School has won as the Most Functional Library in the elementary category while Lucena Dalahican National High School won in the secondary category...
                                    </p>
                                </div>
                                <div class="readmore"><a href="misc/news/news2.php">Read More</a></div>
                            </div>
                        </div>
                        
                        <div class="rightside">
                            <div class="timedate">
                                <div id="greet"></div>
                                <p>The time is</p>
                                <div id="time"></div>
                                <div id="date"></div>
                            </div>
                            
                            <div class="buttonhome">
                                <a href="misc/bookreviews.php"><div class="imagebox"><img src="files/pictures/icon/review.png" width="80%" /><br></div>
                                <p>Book Reviews</p> </a>   
                            </div>
                            
                        </div>
                </div>
            </div>
        </div>
        <script type="text/javascript" src="scripts/script.js"></script>
    </body>
</html>