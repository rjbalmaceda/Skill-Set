<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./styles/style.css">
        <link rel="icon" href="files/pictures/logo/mseuf.png">
        <title>About | MSEUF University Libraries</title>
    </head>
    <body>
        <div class="user_status">
            <?php
                if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 1){
                    echo '<span><form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                            </form>
                            <form action="admin/dashboard.php">
                                <input class="signoutbutton" type="submit" value="Admin Dashboard"/>
                            </form>
                        </span>';
                }
                else if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 2){
                    echo '<form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                        </form>';
                }
                else{
                    echo "<p>Hello <b>GUEST!</b><a href='signinout/signin.php'>Sign In</a></p>";
                }
            ?>
        </div>
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img src="files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1>UNIVERSITY LIBRARIES</h1>
                        <img src="files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a id="active" href="about.php">About</a></li> 
                        <li><a href="personnel.php">Personnel</a></li>
                        <li><a href="facilities.php">Facilities</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li class="search-bar">
                            <form method="post" action="misc/search.php">
                                <input type="text" name="search" placeholder="Search for files here..." />
                                <button class="search-button" type="submit" name="submit-search">Search</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="main">
                <div class="buttons about">
                    <ul>
                        <li><a href="about/history.php"><img src="files/pictures/icon/history.png"/>History</a></li>
                        <li><a href="about/missionvision.php"><img src="files/pictures/icon/missionvision.png"/>Mission-Vision</a></li>
                        <li><a href="about/qualobj.php"><img src="files/pictures/icon/qualobj.jpg"/>Quality Objectives</a></li>
                        <li><a href="about/cdp.php"><img src="files/pictures/icon/cdp.png"/>Collection Development Policy</a></li>
                        <li><a href="about/libcommittee.php"><img src="files/pictures/icon/committee.png"/>Library Committee</a></li>
                    </ul>
                </div>
        </div>

        <script type="text/javascript" src="scripts/script.js"></script>
    </body>
</html>