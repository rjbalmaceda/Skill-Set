<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="styles/style.css">
        <link rel="icon" href="files/pictures/logo/mseuf.png">
        <title>Facilities | MSEUF University Libraries</title>
    </head>
    <body>
        <div class="user_status">
            <?php
                if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 1){
                    echo '<span><form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                            </form>
                            <form action="admin/dashboard.php">
                                <input class="signoutbutton" type="submit" value="Admin Dashboard"/>
                            </form>
                        </span>';
                }
                else if(isset($_SESSION['u_id']) && $_SESSION['u_accnt_type'] == 2){
                    echo '<form method="post" action="includes/signout-inc.php">
                            <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
                                <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
                        </form>';
                }
                else{
                    echo "<p>Hello <b>GUEST!</b><a href='signinout/signin.php'>Sign In</a></p>";
                }
            ?>
        </div>
        <div class="headerbg">
                <div id="headerbar"></div>
                <div id="header"></div>
                <div id="menu"></div>
        </div>
        <div class="container">
            <div class="headercontent">
                <div class="header">
                    <img src="files/pictures/logo/MSEUF.png" width="100px" height="100px"/>
                    <div class="headertitle">
                        <h3>Manuel S. Enverga University Foundation</h3>
                        <h1>UNIVERSITY LIBRARIES</h1>
                        <img src="files/pictures/headerpiclib.png"/>
                    </div>
                </div>
                <div class="menu" id="navbar">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li> 
                        <li><a href="personnel.php">Personnel</a></li>
                        <li><a id="active" href="facilities.php">Facilities</a></li>
                        <li><a href="services.php">Services</a>
                        </li>
                        <li class="search-bar">
                            <form method="post" action="misc/search.php">
                                <input type="text" name="search" placeholder="Search for files here..." />
                                <button class="search-button" type="submit" name="submit-search">Search</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="main">
                <div class="buttons">
                    <ul>
                        <li><a href="facilities/crs.php"><img src="files/pictures/icon/CRS.png"/>CRS</a></li>
                        <li><a href="facilities/rfs.php"><img src="files/pictures/icon/reference.png"/>RFS</a></li>
                        <li><a href="facilities/igsrl.php"><img src="files/pictures/icon/IGSRL.png"/>IGSRL</a></li>
                        <li><a href="facilities/ps.php"><img src="files/pictures/icon/ps.png"/>PS</a></li>
                        <li><a href="facilities/odul.php"><img src="files/pictures/icon/odul.png"/>ODUL</a></li>
                        <li><a href="facilities/tsu.php"><img src="files/pictures/icon/CMU.png"/>TSU</a></li>
                        <li><a href="facilities/law.php"><img src="files/pictures/icon/law.jpg"/>Law Library</a></li>
                        <li><a href="facilities/cmu.php"><img src="files/pictures/icon/CMU.png"/>CMU</a></li>
                        <li><a href="facilities/luiss.php"><img src="files/pictures/icon/LUISS.png"/>LUISS</a></li>
                        <li><a href="facilities/museum.php"><img src="files/pictures/icon/museum2.jpg"/>Museum</a></li>
                        <li><a href="facilities/emrc.php"><img src="files/pictures/icon/EMRC.png"/>EMRC</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <script type="text/javascript" src="scripts/script.js"></script>
    </body>
</html>