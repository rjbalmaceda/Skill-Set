<?php
    session_start();

    include '../../includes/dbh-inc.php';

    if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$result = mysqli_query($conn, "SELECT * FROM bookrevs WHERE br_id=$id");

		if (count($result) == 1 ) {
			$n = mysqli_fetch_array($result);
			$id = $n['br_id'];
			$title = $n['br_title'];
			$author = $n['br_author'];
			$year = $n['br_year'];
			$reviewer = $n['br_reviewer'];
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../../styles/style.css">
		<link rel="stylesheet" type="text/css" href="../../styles/signinstyle.css">
		<link rel="stylesheet" type="text/css" href="../../styles/adminstyle.css">
		<link href="../../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
	    <link rel="icon" href="../../files/pictures/logo/mseuf.png">
		<title>Edit Book Review | Admin Dashboard</title>
	</head>
	<body>
		<div class="admin-title">
			<p><i class="fa fa-tachometer-alt"></i> Dashboard</p>
			<!-- <div class="user_status">
	            <?php
	                if(isset($_SESSION['u_id'])){
	                    echo '<form method="post" action="../../includes/signout-inc.php">
	                        <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
	                            <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
	                    </form>';
	                }
	            ?>
	            <div><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Exit Dashboard</a></div>
	        </div> -->
		</div>
        <div class="main">
                <div class="stats">
                	<!-------------------------------------USERS----------------------------------------->
                	<div class="admin-card edit">
	                	<div class="admin-card-title">
	                		<span><i class="fas fa-edit"></i> Edit Book Review</span>
	                	</div>

	                	<div class="admin-card-menubar">
	                		<form action="bookrevlist.php"><button class="edit_backbutton"><i class="fas fa-times"></i>&nbsp; Cancel all changes</button></form>
	                	</div>

	                	<div class="admin-card-content">
            				<form method="post" enctype="multipart/form-data" action="../../includes/bookreviews/update-bookrev-inc.php">
            					<input style="display: none" type="number" name="id" value="<?php echo $id ?>">
								<table cellpadding="10">
									<tr>
										<td colspan="2">
											<label>Title</label><br>
											<input class="inputdes" type="text" name="title" value="<?php echo $title?>" />
										</td>
									</tr>
									<tr>
										<td>
											<label>Author</label><br>
											<input class="inputdes" type="text" name="volume" value="<?php echo $author?>"/>
										</td>
										<td>
											<label>Year</label><br>
											<input class="inputdes" type="number" name="year" value="<?php echo $year?>"/>
										</td>
									</tr>
									<tr>
										<td>
											<label>Reviewer</label><br>
											<input class="inputdes" type="text" name="publisher" value="<?php echo $reviewer?>"/>
										</td>
									</tr>
									<tr>
										<td colspan="3">
											<input class="submitbutton" type="submit" name="submit" value="Update"/>
										</td>
									</tr>
								</table>
							</form>
	                	</div>
	                </div>
                </div>
        </div>
        <script type="text/javascript" src="../scripts/modal.js"></script>
	</body>
</html>