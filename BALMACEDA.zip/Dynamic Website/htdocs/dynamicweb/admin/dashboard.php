<?php
    session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../styles/style.css">
		<link rel="stylesheet" type="text/css" href="../styles/signinstyle.css">
		<link rel="stylesheet" type="text/css" href="../styles/adminstyle.css">
		<link href="../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
	    <link rel="icon" href="../files/pictures/logo/mseuf.png">
		<title>Admin Dashboard</title>
	</head>
	<body>
		<div class="admin-title">
			<p><i class="fa fa-tachometer-alt"></i> Dashboard</p>
			<div class="user_status">
	            <!-- <?php
	                if(isset($_SESSION['u_id'])){
	                    echo '<form method="post" action="../includes/signout-inc.php">
	                        <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
	                            <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
	                    </form>';
	                }
	            ?> -->
	            <div><a href="../index.php" class="exit-dashboard"><i class="fas fa-sign-out-alt"></i> <label>Exit Dashboard</label></a></div>
	        </div>
		</div>
        <div class="main">
                <div class="stats">
                	<!-------------------------------------USERS----------------------------------------->
                	<div class="admin-card">
	                	<div class="admin-card-title">
	                		<span><i class="fas fa-users"></i> Users</span>
	                		<span>Total<p>
	                		<?php
	                			include '../includes/dbh-inc.php';

	                			$sql = "SELECT * FROM users";
								$result = mysqli_query($conn, $sql);
								$resultCheck = mysqli_num_rows($result);

								echo $resultCheck;
	                		?>
	                		</p></span>
	                	</div>

	                	<div class="admin-card-menubar">
	                		<form action="users/userlist.php"><button><i class="fas fa-edit"></i>&nbsp; Edit Masterlist</button></form>
	                	</div>

	                	<div class="admin-card-content">
	                		<?php
	                			$sql = "SELECT * FROM users;";
	                			$result = mysqli_query($conn, $sql);
	                			$resultCheck = mysqli_num_rows($result);

	                			if ($resultCheck > 0) {
	                				echo '<div style="overflow-x: auto"><table class="admin_users">
	                						<tr>
							                	<th>UID</th>
							                	<th>Full Name</th>
							                	<th>User Name</th>
							                	<th>Email Address</th>
							                	<th>Account Type</th>
							                </tr>';
	                				while ($row = mysqli_fetch_assoc($result)) {
	                					if($row['accnt_type']=='1'){
	                						$type = 'Administrator';
	                					}else{
	                						$type = 'Standard User';
	                					}
	                					echo '<tr>
							                	<td>'.$row['user_id'].'</td>
							                	<td>'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</td>
							                	<td>'.$row['username'].'</td>
							                	<td>'.$row['email'].'</td>
							                	<td>'.$type.'</td>
							                </tr>';
	                				}
	                				echo '</table></div>';
	                			}
	                		?>
	                	</div>
	                </div>
	                
	                <!-------------------------------------e-JOURNALS----------------------------------------->
	                <div class="admin-card">
	                	<div class="admin-card-title">
	                		<span><i class="fas fa-newspaper"></i> e-Journals</span>
	                		<span>Total<p>
	                			<?php
	                			include '../includes/dbh-inc.php';

	                			$sql = "SELECT * FROM ejournals";
								$result = mysqli_query($conn, $sql);
								$resultCheck = mysqli_num_rows($result);

								echo $resultCheck;
	                		?>
	                		</p></span>
	                	</div>
	                	<div class="admin-card-menubar">
	                		<form action="ejournal/ejournallist.php"><button><i class="fas fa-edit"></i>&nbsp; Edit Masterlist</button></form>
	                	</div>
	                	<div class="admin-card-content">
	                		<?php
	                			$sql = "SELECT * FROM ejournals;";
	                			$result = mysqli_query($conn, $sql);
	                			$resultCheck = mysqli_num_rows($result);

	                			if ($resultCheck > 0) {
	                				echo '<div style="overflow-x: auto"><table class="admin_users edit_table">
	                						<tr>
							                	<th>Title</th>
							                	<th>Volume</th>
							                	<th>Year</th>
							                	<th>Publisher</th>
							                	<th>View</th>
							                </tr>';
	                				while ($row = mysqli_fetch_assoc($result)) {
	                					echo '<tr>
							                	<td>'.$row['j_title'].'</td>
							                	<td>'.$row['j_volume'].'</td>
							                	<td>'.$row['j_year'].'</td>
							                	<td>'.$row['j_publisher'].'</td>
							                	<td><a target="_blank" href="../'.$row['j_file'].'"><i class="fas fa-external-link-alt"></i></a></td>
							                </tr>';
	                				}
	                				echo '</table></div>';
	                			}
	                			else{
	                				echo 'There are no e-Journals uploaded.';
	                			}
	                		?>
	                	</div>
	                </div>
	                <!-------------------------------------e-BOOKS----------------------------------------->
	                <div class="admin-card">
	                	<div class="admin-card-title">
	                		<span><i class="fas fa-book"></i> e-Books</span>
	                		<span>Total<p>
	                		<?php
	                			include '../includes/dbh-inc.php';

	                			$sql = "SELECT * FROM ebooks";
								$result = mysqli_query($conn, $sql);
								$resultCheck = mysqli_num_rows($result);

								echo $resultCheck;
	                		?>
	                		</p></span>
	                	</div>
	                	<div class="admin-card-menubar">
	                		<form action="ebook/ebooklist.php"><button><i class="fas fa-edit"></i>&nbsp; Edit Masterlist</button></form>
	                	</div>
	                	<div class="admin-card-content">
	                		<?php
	                			$sql = "SELECT * FROM ebooks;";
	                			$result = mysqli_query($conn, $sql);
	                			$resultCheck = mysqli_num_rows($result);

	                			if ($resultCheck > 0) {
	                				echo '<div style="overflow-x: auto"><table class="admin_users edit_table">
	                						<tr>
							                	<th>Title</th>
							                	<th>Author</th>
							                	<th>Year</th>
							                	<th>View</th>
							                </tr>';
	                				while ($row = mysqli_fetch_assoc($result)) {
	                					echo '<tr>
							                	<td>'.$row['b_title'].'</td>
							                	<td>'.$row['b_author'].'</td>
							                	<td>'.$row['b_year'].'</td>
							                	<td><a target="_blank" href="../'.$row['b_file'].'"><i class="fas fa-external-link-alt"></i></a></td>
							                </tr>';
	                				}
	                				echo '</table></div>';
	                			}
	                			else{
	                				echo 'There are no e-Books uploaded.';
	                			}
	                		?>
	                	</div>
	                </div>
	                <!-------------------------------------BOOK REVIEWS----------------------------------------->
	                <div class="admin-card">
	                	<div class="admin-card-title">
	                		<span><i class="fas fa-file-alt"></i> Book Reviews</span>
	                		<span>Total<p>
	                		<?php
	                			include '../includes/dbh-inc.php';

	                			$sql = "SELECT * FROM bookrevs";
								$result = mysqli_query($conn, $sql);
								$resultCheck = mysqli_num_rows($result);

								echo $resultCheck;
	                		?>
	                		</p></span>
	                	</div>
	                	<div class="admin-card-menubar">
	                		<form action="bookreview/bookrevlist.php"><button><i class="fas fa-edit"></i>&nbsp; Edit Masterlist</button></form>
	                	</div>
	                	<div class="admin-card-content">
	                		<?php
	                			$sql = "SELECT * FROM bookrevs;";
	                			$result = mysqli_query($conn, $sql);
	                			$resultCheck = mysqli_num_rows($result);

	                			if ($resultCheck > 0) {
	                				echo '<div style="overflow-x: auto"><table class="admin_users edit_table">
	                						<tr>
							                	<th>Title</th>
							                	<th>Author</th>
							                	<th>Year</th>
							                	<th>Reviewer</th>
							                	<th>View</th>
							                </tr>';
	                				while ($row = mysqli_fetch_assoc($result)) {
	                					echo '<tr>
							                	<td>'.$row['br_title'].'</td>
							                	<td>'.$row['br_author'].'</td>
							                	<td>'.$row['br_year'].'</td>
							                	<td>'.$row['br_reviewer'].'</td>
							                	<td><a target="_blank" href="../'.$row['br_file'].'"><i class="fas fa-external-link-alt"></i></a></td>
							                </tr>';
	                				}
	                				echo '</table></div>';
	                			}
	                			else{
	                				echo 'There are no Book Reviews uploaded.';
	                			}
	                		?>
	                	</div>
	                </div>
                </div>
        </div>
        <script type="text/javascript" src="../scripts/modal.js"></script>
	</body>
</html>