<?php
    session_start();

    include '../../includes/dbh-inc.php';

    if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$result = mysqli_query($conn, "SELECT * FROM ejournals WHERE j_id=$id");

		if (count($result) == 1 ) {
			$n = mysqli_fetch_array($result);
			$id = $n['j_id'];
			$title = $n['j_title'];
			$volume = $n['j_volume'];
			$year = $n['j_year'];
			$publisher = $n['j_publisher'];
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../../styles/style.css">
		<link rel="stylesheet" type="text/css" href="../../styles/signinstyle.css">
		<link rel="stylesheet" type="text/css" href="../../styles/adminstyle.css">
		<link href="../../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
	    <link rel="icon" href="../../files/pictures/logo/mseuf.png">
		<title>Edit E-Journal | Admin Dashboard</title>
	</head>
	<body>
		<div class="admin-title">
			<p><i class="fa fa-tachometer-alt"></i> Dashboard</p>
			<!-- <div class="user_status">
	            <?php
	                if(isset($_SESSION['u_id'])){
	                    echo '<form method="post" action="../../includes/signout-inc.php">
	                        <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
	                            <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
	                    </form>';
	                }
	            ?>
	            <div><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Exit Dashboard</a></div>
	        </div> -->
		</div>
        <div class="main">
                <div class="stats">
                	<!-------------------------------------USERS----------------------------------------->
                	<div class="admin-card edit">
	                	<div class="admin-card-title">
	                		<span><i class="fas fa-edit"></i> Edit E-Journal</span>
	                	</div>

	                	<div class="admin-card-menubar">
	                		<form action="ejournallist.php"><button class="edit_backbutton"><i class="fas fa-times"></i>&nbsp; Cancel all changes</button></form>
	                	</div>

	                	<div class="admin-card-content">
            				<form method="post" name="j_upload" enctype="multipart/form-data" action="../../includes/ejournals/update-ejournal-inc.php">
            					<input style="display: none" type="number" name="j_id" value="<?php echo $id ?>">
								<table cellpadding="10">
									<tr>
										<td colspan="2">
											<label>Title</label><br>
											<input class="inputdes" type="text" name="j_title" value="<?php echo $title?>" />
										</td>
									</tr>
									<tr>
										<td>
											<label>Volume</label><br>
											<input class="inputdes" type="text" name="j_volume" value="<?php echo $volume?>"/>
										</td>
										<td>
											<label>Year</label><br>
											<input class="inputdes" type="number" name="j_year" value="<?php echo $year?>"/>
										</td>
									</tr>
									<tr>
										<td>
											<label>Publisher</label><br>
											<input class="inputdes" type="text" name="j_publisher" value="<?php echo $publisher?>"/>
										</td>
									</tr>
									<tr>
										<td colspan="3">
											<input class="submitbutton" type="submit" name="submit" value="Update"/>
										</td>
									</tr>
								</table>
							</form>
	                	</div>
	                </div>
                </div>
        </div>
        <script type="text/javascript" src="../scripts/modal.js"></script>
	</body>
</html>