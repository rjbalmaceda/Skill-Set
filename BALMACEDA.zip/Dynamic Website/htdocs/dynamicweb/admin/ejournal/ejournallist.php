<?php
    session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../../styles/style.css">
		<link rel="stylesheet" type="text/css" href="../../styles/signinstyle.css">
		<link rel="stylesheet" type="text/css" href="../../styles/adminstyle.css">
		<link href="../../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
	    <link rel="icon" href="../../files/pictures/logo/mseuf.png">
		<title>E-Journal Masterlist | Admin Dashboard</title>
	</head>
	<body>
		<div class="admin-title">
			<p><i class="fa fa-tachometer-alt"></i> Dashboard</p>
			<!-- <div class="user_status">
	            <?php
	                if(isset($_SESSION['u_id'])){
	                    echo '<form method="post" action="../../includes/signout-inc.php">
	                        <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
	                            <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
	                    </form>';
	                }
	            ?>
	            <div><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Exit Dashboard</a></div>
	        </div> -->
		</div>
        <div class="main">
                <div class="stats">
                	<!-------------------------------------USERS----------------------------------------->
                	<div class="admin-card list">
	                	<div class="admin-card-title">
	                		<span><i class="fas fa-newspaper"></i> e-Journal Masterlist</span>
	                		<span>Total<p>
	                		<?php
	                			include '../../includes/dbh-inc.php';

	                			$sql = "SELECT * FROM ejournals";
								$result = mysqli_query($conn, $sql);
								$resultCheck = mysqli_num_rows($result);

								echo $resultCheck;
	                		?>
	                		</p></span>
	                	</div>

	                	<div class="admin-card-menubar">
	                		<form action="../dashboard.php"><button class="edit_backbutton"><i class="fas fa-arrow-left"></i>&nbsp; Back</button></form>
	                		<button id="modalBtn"><i class="fas fa-plus"></i>&nbsp; Add e-Journal</button>
	                	</div>

	                	<div class="admin-card-content">
	                		<div id="simpleModal" class="modal">
	                			<div class="modal-wrapper">
	                				<div class="modal-title">
		                				<span class="closeBtn">&times;</span>
		                				<p><i class="fas fa-plus-circle"></i> Add e-Journal</p>
		                			</div>
		                			<div class="modal-content">
		                				<form method="post" name="j_upload" enctype="multipart/form-data" action="../../includes/ejournals/upload-ejournal-inc.php">
											<table cellpadding="10">
												<tr>
													<td colspan="2">
														<label>Title</label><br>
														<input class="inputdes" type="text" name="j_title"/>
													</td>
												</tr>
												<tr>
													<td>
														<label>Volume</label><br>
														<input class="inputdes" type="text" name="j_volume"/>
													</td>
													<td>
														<label>Year</label><br>
														<input class="inputdes" type="number" name="j_year"/>
													</td>
												</tr>
												<tr>
													<td>
														<label>Publisher</label><br>
														<input class="inputdes" type="text" name="j_publisher"/>
													</td>
													<td>
														<label>Upload File</label><br>
														<input class="inputdes" type="file" name="file"/>
													</td>
												</tr>
												<tr>
													<td colspan="3">
														<input class="submitbutton" type="submit" name="submit" value="Save & Upload"/>
													</td>
												</tr>
											</table>
										</form>
									</div>
	                			</div>
	                		</div>
	                		<?php
	                			$sql = "SELECT * FROM ejournals;";
	                			$result = mysqli_query($conn, $sql);
	                			$resultCheck = mysqli_num_rows($result);

	                			if ($resultCheck > 0) {
	                				echo '<div style="overflow-x: auto"><table class="admin_users edit_table">
	                						<tr>
							                	<th>Title</th>
							                	<th>Volume</th>
							                	<th>Year</th>
							                	<th>Publisher</th>						                	
							                	<th>View/Download</th>
							                	<th>Edit</th>
							                	<th>Delete</th>
							                </tr>';                                                                                                                                                                                                                                                                                                                                         
	                				while ($row = mysqli_fetch_assoc($result)) {
	                					echo '<tr>
							                	<td>'.$row['j_title'].'</td>
							                	<td>'.$row['j_volume'].'</td>
							                	<td>'.$row['j_year'].'</td>
							                	<td>'.$row['j_publisher'].'</td>
							                	<td><a target="_blank" href="../../'.$row['j_file'].'"><i class="fas fa-external-link-alt"></i></a></td>
							                	<td><a href="editejournal.php?edit='.$row['j_id'].'"><i class="fas fa-edit edit_icon"></i></a></td>
							                	<td><a href="../../includes/ejournals/delete-ejournal-inc.php?del='.$row['j_id'].'"><i class="fas fa-trash-alt"></i></td>
							                </tr>';
	                				}
	                				echo '</table></div>';
	                			}
	                		?>
	                	</div>
	                </div>
                </div>
        </div>
        <script type="text/javascript" src="../../scripts/modal.js"></script>
	</body>
</html>