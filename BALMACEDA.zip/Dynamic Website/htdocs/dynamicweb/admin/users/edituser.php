<?php
    session_start();

    include '../../includes/dbh-inc.php';

    if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$result = mysqli_query($conn, "SELECT * FROM users WHERE user_id=$id");

		if (count($result) == 1 ) {
			$n = mysqli_fetch_array($result);
			$fname = $n['first_name'];
			$mname = $n['middle_name'];
			$lname = $n['last_name'];
			$username = $n['username'];
			$email = $n['email'];
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../../styles/style.css">
		<link rel="stylesheet" type="text/css" href="../../styles/signinstyle.css">
		<link rel="stylesheet" type="text/css" href="../../styles/adminstyle.css">
		<link href="../../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
	    <link rel="icon" href="../../files/pictures/logo/mseuf.png">
		<title>Edit User | Admin Dashboard</title>
	</head>
	<body>
		<div class="admin-title">
			<p><i class="fa fa-tachometer-alt"></i> Dashboard</p>
			<!-- <div class="user_status">
	            <?php
	                if(isset($_SESSION['u_id'])){
	                    echo '<form method="post" action="../../includes/signout-inc.php">
	                        <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
	                            <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
	                    </form>';
	                }
	            ?>
	            <div><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Exit Dashboard</a></div>
	        </div> -->
		</div>
        <div class="main">
                <div class="stats">
                	<!-------------------------------------USERS----------------------------------------->
                	<div class="admin-card edit">
	                	<div class="admin-card-title">
	                		<span><i class="fas fa-edit"></i> Edit User</span>
	                	</div>

	                	<div class="admin-card-menubar">
	                		<form action="userlist.php"><button class="edit_backbutton"><i class="fas fa-times"></i>&nbsp; Cancel all changes</button></form>
	                	</div>

	                	<div class="admin-card-content">
            				<form method="post" name="signup" action="../../includes/users/update-user-inc.php">
            					<input style="display: none" type="text" name="id" value="<?php echo $id?>" />
								<table cellpadding="10">
									<tr>
										<td>
											<label>First Name</label><br>
											<input class="inputdes" type="text" name="fname" value="<?php echo $fname?>" />
										</td>
										<td>
											<label>Middle Name</label><br>
											<input class="inputdes" type="text" name="mname" value="<?php echo $mname?>"/>
										</td>
										<td>
											<label>Last Name</label><br>
											<input class="inputdes" type="text" name="lname" value="<?php echo $lname?>"/>
										</td>
									</tr>
									<tr>
										<td>
											<label>Username</label><br>
											<input class="inputdes" type="text" name="username" value="<?php echo $username?>"/>
										</td>
										<td colspan="2">
											<label>Email Address</label><br>
											<input class="inputdes" type="email" name="email" value="<?php echo $email?>"/>
										</td>
									</tr>
									<tr>
										<td>
											<label>New Password</label><br>
											<input class="inputdes" type="password" name="password"/>
										</td>
										<td>
											<label>Confirm New Password</label><br>
											<input class="inputdes" type="password" name="confirmpassword"/>
										</td>
										<td>
											<label>Account Type</label><br>
											<select class="inputdes" name="accnt_type">
												<option value="1">Administrator</option>
												<option value="2" selected="selected">Standard User</option>
											</select>
										</td>
									</tr>
									<tr>
										<td colspan="3">
											<input class="submitbutton" type="submit" name="submit" value="Update"/>
										</td>
									</tr>
								</table>
							</form>
	                	</div>
	                </div>
                </div>
        </div>
        <script type="text/javascript" src="../scripts/modal.js"></script>
	</body>
</html>