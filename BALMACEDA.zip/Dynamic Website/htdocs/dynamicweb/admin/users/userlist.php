<?php
    session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../../styles/style.css">
		<link rel="stylesheet" type="text/css" href="../../styles/signinstyle.css">
		<link rel="stylesheet" type="text/css" href="../../styles/adminstyle.css">
		<link href="../../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
	    <link rel="icon" href="../../files/pictures/logo/mseuf.png">
		<title>User Masterlist | Admin Dashboard</title>
	</head>
	<body>
		<div class="admin-title">
			<p><i class="fa fa-tachometer-alt"></i> Dashboard</p>
			<!-- <div class="user_status">
	            <?php
	                if(isset($_SESSION['u_id'])){
	                    echo '<form method="post" action="../../includes/signout-inc.php">
	                        <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
	                            <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
	                    </form>';
	                }
	            ?>
	            <div><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Exit Dashboard</a></div>
	        </div> -->
		</div>
        <div class="main">
                <div class="stats">
                	<!-------------------------------------USERS----------------------------------------->
                	<div class="admin-card list">
	                	<div class="admin-card-title">
	                		<span><i class="fas fa-users"></i> User Masterlist</span>
	                		<span>Total<p>
	                		<?php
	                			include '../../includes/dbh-inc.php';

	                			$sql = "SELECT * FROM users";
								$result = mysqli_query($conn, $sql);
								$resultCheck = mysqli_num_rows($result);

								echo $resultCheck;
	                		?>
	                		</p></span>
	                	</div>

	                	<div class="admin-card-menubar">
	                		<form action="../dashboard.php"><button class="edit_backbutton"><i class="fas fa-arrow-left"></i>&nbsp; Back</button></form>
	                		<button id="modalBtn"><i class="fas fa-plus"></i>&nbsp; Add User</button>
	                	</div>

	                	<div class="admin-card-content">
	                		<div id="simpleModal" class="modal">
	                			<div class="modal-wrapper">
	                				<div class="modal-title">
		                				<span class="closeBtn">&times;</span>
		                				<p><i class="fas fa-user-plus"></i> Add User</p>
		                			</div>
		                			<div class="modal-content">
		                				<form method="post" name="signup" action="../../includes/signup-admin-inc.php">
											<table cellpadding="10">
												<tr>
													<td>
														<label>First Name</label><br>
														<input class="inputdes" type="text" name="fname"/>
													</td>
													<td>
														<label>Middle Name</label><br>
														<input class="inputdes" type="text" name="mname"/>
													</td>
													<td>
														<label>Last Name</label><br>
														<input class="inputdes" type="text" name="lname"/>
													</td>
												</tr>
												<tr>
													<td>
														<label>Username</label><br>
														<input class="inputdes" type="text" name="username"/>
													</td>
													<td colspan="2">
														<label>Email Address</label><br>
														<input class="inputdes" type="email" name="email"/>
													</td>
												</tr>
												<tr>
													<td>
														<label>Password</label><br>
														<input class="inputdes" type="password" name="password"/>
													</td>
													<td>
														<label>Confirm Password</label><br>
														<input class="inputdes" type="password" name="confirmpassword"/>
													</td>
													<td>
														<label>Account Type</label><br>
														<select class="inputdes" name="accnt_type">
															<option value="1">Administrator</option>
															<option value="2" selected="selected">Standard User</option>
														</select>
													</td>
												</tr>
												<tr>
													<td colspan="3">
														<input class="submitbutton" type="submit" name="submit" value="Sign Up"/>
													</td>
												</tr>
											</table>
										</form>
									</div>
	                			</div>
	                		</div>
	                		<?php
	                			$sql = "SELECT * FROM users;";
	                			$result = mysqli_query($conn, $sql);
	                			$resultCheck = mysqli_num_rows($result);

	                			if ($resultCheck > 0) {
	                				echo '<div style="overflow-x: auto"><table class="admin_users edit_table">
	                						<tr>
							                	<th>UID</th>
							                	<th>Full Name</th>
							                	<th>User Name</th>
							                	<th>Email Address</th>
							                	<th>Account Type</th>
							                	<th>Edit</th>
							                	<th>Delete</th>
							                </tr>';
	                				while ($row = mysqli_fetch_assoc($result)) {
	                					if($row['accnt_type']=='1'){
	                						$type = 'Administrator';
	                					}else{
	                						$type = 'Standard User';
	                					}
	                					echo '<tr>
							                	<td>'.$row['user_id'].'</td>
							                	<td>'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</td>
							                	<td>'.$row['username'].'</td>
							                	<td>'.$row['email'].'</td>
							                	<td>'.$type.'</td>
							                	<td><a href="edituser.php?edit='.$row['user_id'].'"><i class="fas fa-edit edit_icon"></i></a></td>
							                	<td><a href="../../includes/users/delete-user-inc.php?del='.$row['user_id'].'"><i class="fas fa-trash-alt"></i></td>
							                </tr>';
	                				}
	                				echo '</table></div>';
	                			}
	                		?>
	                	</div>
	                </div>
                </div>
        </div>
        <script type="text/javascript" src="../../scripts/modal.js"></script>
	</body>
</html>