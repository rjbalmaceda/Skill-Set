<?php
    session_start();

    include '../../includes/dbh-inc.php';

    if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$result = mysqli_query($conn, "SELECT * FROM ebooks WHERE b_id=$id");

		if (count($result) == 1 ) {
			$n = mysqli_fetch_array($result);
			$id = $n['b_id'];
			$title = $n['b_title'];
			$author = $n['b_author'];
			$year = $n['b_year'];
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../../styles/style.css">
		<link rel="stylesheet" type="text/css" href="../../styles/signinstyle.css">
		<link rel="stylesheet" type="text/css" href="../../styles/adminstyle.css">
		<link href="../../files/fontawesome/css/fontawesome-all.css" rel="stylesheet">
	    <link rel="icon" href="../../files/pictures/logo/mseuf.png">
		<title>Edit E-Book | Admin Dashboard</title>
	</head>
	<body>
		<div class="admin-title">
			<p><i class="fa fa-tachometer-alt"></i> Dashboard</p>
			<!-- <div class="user_status">
	            <?php
	                if(isset($_SESSION['u_id'])){
	                    echo '<form method="post" action="../../includes/signout-inc.php">
	                        <p>Hello <b>'.$_SESSION["u_fname"].'!</b>
	                            <input class="signoutbutton" type="submit" name="submit" value="Sign Out" /></p>
	                    </form>';
	                }
	            ?>
	            <div><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Exit Dashboard</a></div>
	        </div> -->
		</div>
        <div class="main">
                <div class="stats">
                	<!-------------------------------------USERS----------------------------------------->
                	<div class="admin-card edit">
	                	<div class="admin-card-title">
	                		<span><i class="fas fa-edit"></i> Edit E-Book</span>
	                	</div>

	                	<div class="admin-card-menubar">
	                		<form action="ebooklist.php"><button class="edit_backbutton"><i class="fas fa-times"></i>&nbsp; Cancel all changes</button></form>
	                	</div>

	                	<div class="admin-card-content">
            				<form method="post" name="b_upload" enctype="multipart/form-data" action="../../includes/ebooks/update-ebook-inc.php">
            					<input style="display: none" type="number" name="id" value="<?php echo $id ?>">
								<table cellpadding="10">
									<tr>
										<td colspan="2">
											<label>Title</label><br>
											<input class="inputdes" type="text" name="title" value="<?php echo $title?>" />
										</td>
									</tr>
									<tr>
										<td>
											<label>Volume</label><br>
											<input class="inputdes" type="text" name="author" value="<?php echo $author?>"/>
										</td>
										<td>
											<label>Year</label><br>
											<input class="inputdes" type="number" name="year" value="<?php echo $year?>"/>
										</td>
									</tr>
									<tr>
										<td colspan="2">
											<input class="submitbutton" type="submit" name="submit" value="Update"/>
										</td>
									</tr>
								</table>
							</form>
	                	</div>
	                </div>
                </div>
        </div>
        <script type="text/javascript" src="../scripts/modal.js"></script>
	</body>
</html>